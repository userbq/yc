/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define SB2_Pin GPIO_PIN_2
#define SB2_GPIO_Port GPIOE
#define SB3_Pin GPIO_PIN_3
#define SB3_GPIO_Port GPIOE
#define SB4_Pin GPIO_PIN_4
#define SB4_GPIO_Port GPIOE
#define SB5_Pin GPIO_PIN_5
#define SB5_GPIO_Port GPIOE
#define LED1_Pin GPIO_PIN_5
#define LED1_GPIO_Port GPIOA
#define LED2_Pin GPIO_PIN_6
#define LED2_GPIO_Port GPIOA
#define OLED_CS_Pin GPIO_PIN_7
#define OLED_CS_GPIO_Port GPIOD
#define OLED_DC_Pin GPIO_PIN_3
#define OLED_DC_GPIO_Port GPIOB
#define OLED_RES_Pin GPIO_PIN_4
#define OLED_RES_GPIO_Port GPIOB
#define OLED_SDA_Pin GPIO_PIN_5
#define OLED_SDA_GPIO_Port GPIOB
#define OLED_SCK_Pin GPIO_PIN_6
#define OLED_SCK_GPIO_Port GPIOB
#define SB0_Pin GPIO_PIN_0
#define SB0_GPIO_Port GPIOE
#define SB1_Pin GPIO_PIN_1
#define SB1_GPIO_Port GPIOE

/* USER CODE BEGIN Private defines */
#define u8 uint8_t
#define  u16 uint16_t
#define  u32 uint32_t
#define s8  int8_t
#define s16 int16_t
#define s32 int32_t
#define s64 int64_t

/* SB0~SB5 map to PE0~PE5 */
#define SB0_Pin GPIO_PIN_0
#define SB0_GPIO_Port GPIOE
#define SB1_Pin GPIO_PIN_1
#define SB1_GPIO_Port GPIOE
#define SB2_Pin GPIO_PIN_2
#define SB2_GPIO_Port GPIOE
#define SB3_Pin GPIO_PIN_3
#define SB3_GPIO_Port GPIOE
#define SB4_Pin GPIO_PIN_4
#define SB4_GPIO_Port GPIOE
#define SB5_Pin GPIO_PIN_5
#define SB5_GPIO_Port GPIOE

#define SB0 (HAL_GPIO_ReadPin(SB0_GPIO_Port, SB0_Pin))
#define SB1 (HAL_GPIO_ReadPin(SB1_GPIO_Port, SB1_Pin))
#define SB2 (HAL_GPIO_ReadPin(SB2_GPIO_Port, SB2_Pin))
#define SB3 (HAL_GPIO_ReadPin(SB3_GPIO_Port, SB3_Pin))
#define SB4 (HAL_GPIO_ReadPin(SB4_GPIO_Port, SB4_Pin))
#define SB5 (HAL_GPIO_ReadPin(SB5_GPIO_Port, SB5_Pin))
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
