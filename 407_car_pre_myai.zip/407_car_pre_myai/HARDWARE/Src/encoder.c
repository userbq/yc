#include "encoder.h"
#include "tim.h"
#include <math.h>

#define ENCODER_COUNTS_PER_REV  2288
#define ENCODER_SAMPLE_MS       10
#define ENCODER_RPM_FACTOR      (60000.0f / (ENCODER_SAMPLE_MS * ENCODER_COUNTS_PER_REV))

#define ENCODER_LEFT_POLARITY   (-1)
#define ENCODER_RIGHT_POLARITY  (1)

#define FILTER_THRESHOLD_RPM    18.0f
#define STAGE1_ALPHA_FAST       0.70f
#define STAGE1_ALPHA_SLOW       0.45f
#define STAGE2_ALPHA_FAST       0.30f
#define STAGE2_ALPHA_SLOW       0.16f

#define ZERO_DIFF_LIMIT         2

static int32_t  left_last_count;
static int32_t  right_last_count;
static float    left_stage1_rpm;
static float    left_filtered_rpm;
static float    right_stage1_rpm;
static float    right_filtered_rpm;
static uint8_t  left_zero_diff_count;
static uint8_t  right_zero_diff_count;

static int32_t encoder_diff_32(int32_t current, int32_t last)
{
    int32_t diff = current - last;
    if (diff >= 32768)
        diff -= 65536;
    else if (diff < -32768)
        diff += 65536;
    return diff;
}

static int32_t encoder_diff_32ext(int32_t current, int32_t last)
{
    int64_t diff = (int64_t)current - (int64_t)last;
    int64_t half = 2147483648LL;
    if (diff >= half)
        diff -= 4294967296LL;
    else if (diff < -half)
        diff += 4294967296LL;
    return (int32_t)diff;
}

static float adaptive_lowpass(float input, float *state, float threshold,
                               float alpha_fast, float alpha_slow)
{
    float diff = fabsf(input - *state);
    float alpha = (diff >= threshold) ? alpha_fast : alpha_slow;
    *state = *state + alpha * (input - *state);
    return *state;
}

void Encoder_InitAll(void)
{
    HAL_TIM_Encoder_Start(&htim2, TIM_CHANNEL_ALL);
    HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);

    left_last_count = 0;
    right_last_count = 0;
    left_stage1_rpm = 0.0f;
    left_filtered_rpm = 0.0f;
    right_stage1_rpm = 0.0f;
    right_filtered_rpm = 0.0f;
    left_zero_diff_count = 0;
    right_zero_diff_count = 0;
}

void Encoder_Update10ms(void)
{
    int32_t left_cur = (int32_t)__HAL_TIM_GET_COUNTER(&htim2);
    int32_t right_cur = (int32_t)__HAL_TIM_GET_COUNTER(&htim4);

    int32_t left_diff = encoder_diff_32ext(left_cur, left_last_count);
    int32_t right_diff = encoder_diff_32(right_cur, right_last_count);

    left_last_count = left_cur;
    right_last_count = right_cur;

    float left_raw_rpm = left_diff * ENCODER_RPM_FACTOR * ENCODER_LEFT_POLARITY;
    float right_raw_rpm = right_diff * ENCODER_RPM_FACTOR * ENCODER_RIGHT_POLARITY;

    if (left_diff == 0) {
        if (left_zero_diff_count < 255) left_zero_diff_count++;
    } else {
        left_zero_diff_count = 0;
    }
    if (right_diff == 0) {
        if (right_zero_diff_count < 255) right_zero_diff_count++;
    } else {
        right_zero_diff_count = 0;
    }

    if (left_zero_diff_count >= ZERO_DIFF_LIMIT) {
        left_stage1_rpm = 0.0f;
        left_filtered_rpm = 0.0f;
    } else {
        adaptive_lowpass(left_raw_rpm, &left_stage1_rpm, FILTER_THRESHOLD_RPM,
                         STAGE1_ALPHA_FAST, STAGE1_ALPHA_SLOW);
        adaptive_lowpass(left_stage1_rpm, &left_filtered_rpm, FILTER_THRESHOLD_RPM,
                         STAGE2_ALPHA_FAST, STAGE2_ALPHA_SLOW);
    }

    if (right_zero_diff_count >= ZERO_DIFF_LIMIT) {
        right_stage1_rpm = 0.0f;
        right_filtered_rpm = 0.0f;
    } else {
        adaptive_lowpass(right_raw_rpm, &right_stage1_rpm, FILTER_THRESHOLD_RPM,
                         STAGE1_ALPHA_FAST, STAGE1_ALPHA_SLOW);
        adaptive_lowpass(right_stage1_rpm, &right_filtered_rpm, FILTER_THRESHOLD_RPM,
                         STAGE2_ALPHA_FAST, STAGE2_ALPHA_SLOW);
    }
}

float Encoder_GetLeftSpeedRPM(void)
{
    return left_filtered_rpm;
}

float Encoder_GetRightSpeedRPM(void)
{
    return right_filtered_rpm;
}

float Encoder_GetCurrentSpeedRPM(void)
{
    float left = left_filtered_rpm;
    float right = right_filtered_rpm;

    if (left == 0.0f || right == 0.0f)
        return 0.0f;
    if (left * right < 0.0f)
        return 0.0f;

    float abs_l = fabsf(left);
    float abs_r = fabsf(right);
    float min_abs = (abs_l < abs_r) ? abs_l : abs_r;

    return (left > 0.0f) ? min_abs : -min_abs;
}

int32_t Encoder_GetLeftCounterValue(void)
{
    return (int32_t)__HAL_TIM_GET_COUNTER(&htim2);
}

int32_t Encoder_GetRightCounterValue(void)
{
    return (int32_t)__HAL_TIM_GET_COUNTER(&htim4);
}

int32_t Encoder_GetLeftCounterDelta(int32_t start)
{
    int32_t current = (int32_t)__HAL_TIM_GET_COUNTER(&htim2);
    return encoder_diff_32ext(current, start);
}

int32_t Encoder_GetRightCounterDelta(int32_t start)
{
    int32_t current = (int32_t)__HAL_TIM_GET_COUNTER(&htim4);
    return encoder_diff_32(current, start);
}

void Encoder_ResetAll(void)
{
    __HAL_TIM_SET_COUNTER(&htim2, 0);
    __HAL_TIM_SET_COUNTER(&htim4, 0);

    left_last_count = 0;
    right_last_count = 0;
    left_stage1_rpm = 0.0f;
    left_filtered_rpm = 0.0f;
    right_stage1_rpm = 0.0f;
    right_filtered_rpm = 0.0f;
    left_zero_diff_count = 0;
    right_zero_diff_count = 0;
}
