#include "OLED.h"
#include "OLED_Font.h"

/* ================== 硬件引脚映射层 ================== */
#define OLED_W_D0(x)		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6,  (GPIO_PinState)(x)) // SCL
#define OLED_W_D1(x)		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5,  (GPIO_PinState)(x)) // SDA
#define OLED_W_RES(x)		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4,  (GPIO_PinState)(x)) // RES
#define OLED_W_DC(x)		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, (GPIO_PinState)(x)) // DC
#define OLED_W_CS(x)		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_7, (GPIO_PinState)(x)) // CS

/* ================== 底层通信协议层 ================== */
void OLED_SPI_SendByte(uint8_t Byte)
{
	uint8_t i;
	for (i = 0; i < 8; i++)
	{
		OLED_W_D1(!!(Byte & (0x80 >> i)));
		OLED_W_D0(1);
		OLED_W_D0(0);
	}
}

void OLED_WriteCommand(uint8_t Command)
{
	OLED_W_CS(0);
	OLED_W_DC(0);
	OLED_SPI_SendByte(Command);
	OLED_W_CS(1);
}

void OLED_WriteData(uint8_t Data)
{
	OLED_W_CS(0);
	OLED_W_DC(1);
	OLED_SPI_SendByte(Data);
	OLED_W_CS(1);
}

/* ================== 核心控制与基础绘制层 ================== */
void OLED_SetCursor(uint8_t Y, uint8_t X)
{
	OLED_WriteCommand(0xB0 | Y);
	OLED_WriteCommand(0x10 | ((X & 0xF0) >> 4));
	OLED_WriteCommand(0x00 | (X & 0x0F));
}

void OLED_Clear(void)
{
	uint8_t i, j;
	for (j = 0; j < 8; j++)
	{
		OLED_SetCursor(j, 0);
		for(i = 0; i < 128; i++)
		{
			OLED_WriteData(0x00);
		}
	}
}

void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char, OLED_FontSize font)
{
	uint8_t i;

	if (font == OLED_FONT_6X8)
	{
		OLED_SetCursor((Line - 1), (Column - 1) * 6);
		for (i = 0; i < 6; i++)
		{
			OLED_WriteData(OLED_F6x8[Char - ' '][i]);
		}
	}
	else
	{
		OLED_SetCursor((Line - 1) * 2, (Column - 1) * 8);
		for (i = 0; i < 8; i++)
		{
			OLED_WriteData(OLED_F8x16[Char - ' '][i]);
		}
		OLED_SetCursor((Line - 1) * 2 + 1, (Column - 1) * 8);
		for (i = 0; i < 8; i++)
		{
			OLED_WriteData(OLED_F8x16[Char - ' '][i + 8]);
		}
	}
}

void OLED_ShowString(uint8_t Line, uint8_t Column, char *String, OLED_FontSize font)
{
	uint8_t i;
	for (i = 0; String[i] != '\0'; i++)
	{
		OLED_ShowChar(Line, Column + i, String[i], font);
	}
}

/* 内部数学辅助函数 */
uint32_t OLED_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;
	while (Y--) Result *= X;
	return Result;
}

/* ================== 数字与高级格式显示层 ================== */
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length, OLED_FontSize font)
{
	uint8_t i;
	for (i = 0; i < Length; i++)
		OLED_ShowChar(Line, Column + i, Number / OLED_Pow(10, Length - i - 1) % 10 + '0', font);
}

void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length, OLED_FontSize font)
{
	uint8_t i;
	uint32_t Number1;
	if (Number >= 0) {
		OLED_ShowChar(Line, Column, '+', font);
		Number1 = Number;
	} else {
		OLED_ShowChar(Line, Column, '-', font);
		Number1 = -Number;
	}
	for (i = 0; i < Length; i++)
		OLED_ShowChar(Line, Column + i + 1, Number1 / OLED_Pow(10, Length - i - 1) % 10 + '0', font);
}

void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length, OLED_FontSize font)
{
	uint8_t i, SingleNumber;
	for (i = 0; i < Length; i++)
	{
		SingleNumber = Number / OLED_Pow(16, Length - i - 1) % 16;
		if (SingleNumber < 10) OLED_ShowChar(Line, Column + i, SingleNumber + '0', font);
		else OLED_ShowChar(Line, Column + i, SingleNumber - 10 + 'A', font);
	}
}

void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length, OLED_FontSize font)
{
	uint8_t i;
	for (i = 0; i < Length; i++)
		OLED_ShowChar(Line, Column + i, Number / OLED_Pow(2, Length - i - 1) % 2 + '0', font);
}

void OLED_ShowFloat(uint8_t Line, uint8_t Column, double Number, uint8_t IntLength, uint8_t FraLength, OLED_FontSize font)
{
	uint32_t IntPart;
	uint32_t FraPart;

	if (Number >= 0) {
		OLED_ShowChar(Line, Column, ' ', font);
	} else {
		OLED_ShowChar(Line, Column, '-', font);
		Number = -Number;
	}

	IntPart = (uint32_t)Number;
	FraPart = (uint32_t)((Number - IntPart) * OLED_Pow(10, FraLength));

	OLED_ShowNum(Line, Column + 1, IntPart, IntLength, font);
	OLED_ShowChar(Line, Column + 1 + IntLength, '.', font);
	OLED_ShowNum(Line, Column + 1 + IntLength + 1, FraPart, FraLength, font);
}

void OLED_ShowChinese(uint8_t Line, uint8_t Column, uint8_t Chinese_Index)
{
	uint8_t i;
	(void)Chinese_Index;
	OLED_SetCursor((Line - 1) * 2, (Column - 1) * 8);
	for (i = 0; i < 8; i++)
	{
		// OLED_WriteData(OLED_CH16x16[Chinese_Index][i]);
	}
	OLED_SetCursor((Line - 1) * 2 + 1, (Column - 1) * 8);
	for (i = 0; i < 8; i++)
	{
		// OLED_WriteData(OLED_CH16x16[Chinese_Index][i + 8]);
	}
}

/* ================== 初始化层 ================== */
void OLED_Init(void)
{
	HAL_Delay(100);

	OLED_W_D0(0);
	OLED_W_D1(1);
	OLED_W_RES(1);
	OLED_W_DC(1);
	OLED_W_CS(1);

	OLED_W_RES(0);
	HAL_Delay(10);
	OLED_W_RES(1);
	HAL_Delay(10);

	OLED_WriteCommand(0xAE);	//关闭显示
	OLED_WriteCommand(0xD5);	//设置显示时钟分频比/振荡器频率
	OLED_WriteCommand(0x80);
	OLED_WriteCommand(0xA8);	//设置多路复用率
	OLED_WriteCommand(0x3F);
	OLED_WriteCommand(0xD3);	//设置显示偏移
	OLED_WriteCommand(0x00);
	OLED_WriteCommand(0x40);	//设置显示开始行
	OLED_WriteCommand(0xA1);	//设置左右方向，0xA1正常 0xA0左右反置
	OLED_WriteCommand(0xC8);	//设置上下方向，0xC8正常 0xC0上下反置
	OLED_WriteCommand(0xDA);	//设置COM引脚硬件配置
	OLED_WriteCommand(0x12);
	OLED_WriteCommand(0x81);	//设置对比度控制
	OLED_WriteCommand(0xCF);
	OLED_WriteCommand(0xD9);	//设置预充电周期
	OLED_WriteCommand(0xF1);
	OLED_WriteCommand(0xDB);	//设置VCOMH取消选择级别
	OLED_WriteCommand(0x30);
	OLED_WriteCommand(0xA4);	//设置整个显示打开/关闭
	OLED_WriteCommand(0xA6);	//设置正常/倒转显示
	OLED_WriteCommand(0x8D);	//设置充电泵
	OLED_WriteCommand(0x14);
	OLED_WriteCommand(0xAF);	//开启显示

	OLED_Clear();
}
