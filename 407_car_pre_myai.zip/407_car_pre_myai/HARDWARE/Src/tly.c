/*
@ link : http://wit-motion.cn

@ Function:
1. Power on automatic detection sensor
2. Read acceleration, angular velocity, angle and magnetic field data
3. Set switching baud rate parameters

USB-TTL                   STM32Core              	  	JY901s
VCC          -----           VCC               ----     VCC
TX           -----           RX1  (GPIOA_10)   
RX           -----           TX1  (GPIOA_9)
GND          -----           GND               ----     GND
                             RX2  (GPIOA_3)    ----      TX
						    	           TX2  (GPIOA_2)    ----      RX
------------------------------------
*/

#include "usart.h"
#include <string.h>
#include <stdio.h>
#include "wit_c_sdk.h"
#include "tly.h"

#define ACC_UPDATE		0x01
#define GYRO_UPDATE		0x02
#define ANGLE_UPDATE	0x04
#define MAG_UPDATE		0x08
#define READ_UPDATE		0x80

static volatile char s_cDataUpdate = 0, s_cCmd = 0xff;
//const uint32_t c_uiBaud[10] = {0, 4800, 9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600};
//static void CmdProcess(void);
//static void AutoScanSensor(void);
static void SensorUartSend(uint8_t *p_data, uint32_t uiSize);
static void SensorDataUpdata(uint32_t uiReg, uint32_t uiRegNum);

TLY tly;
float fAcc[3], fGyro[3], fAngle[3];
extern uint8_t ucTemp;
void tly_init(void)
{
	HAL_UART_Receive_IT(&huart2, &ucTemp, 1); // 开启串口2接收中断
	WitInit(WIT_PROTOCOL_NORMAL, 0x50);         //初始化函数 WIT_PROTOCOL_NORMAL为标准协议 0x50为设备地址
	WitSerialWriteRegister(SensorUartSend);     //注册向传感器写数据的回调函数
	WitRegisterCallBack(SensorDataUpdata);      //注册获取传感器数据的回调函数
	/*
	printf("\r\n********************** wit-motion normal example  ************************\r\n");
	AutoScanSensor();                           //自动搜索传感器
	while (1)
	{
		CmdProcess();
		if(s_cDataUpdate)
		{
			   for(i = 0; i < 3; i++)
			   {
			    	fAcc[i] = sReg[AX+i] / 32768.0f * 16.0f;              //三维加速度
				    fGyro[i] = sReg[GX+i] / 32768.0f * 2000.0f;           //三维角速度
			   	  fAngle[i] = sReg[Roll+i] / 32768.0f * 180.0f;         //三维角度
			   }
			   if(s_cDataUpdate & ACC_UPDATE)
			   {
				    printf("acc:%.3f %.3f %.3f\r\n", fAcc[0], fAcc[1], fAcc[2]);
				    s_cDataUpdate &= ~ACC_UPDATE;
			   }
			   if(s_cDataUpdate & GYRO_UPDATE)
			   {
			   	printf("gyro:%.3f %.3f %.3f\r\n", fGyro[0], fGyro[1], fGyro[2]);
			   	s_cDataUpdate &= ~GYRO_UPDATE;
			   }
			   if(s_cDataUpdate & ANGLE_UPDATE)
			   {
			   	printf("angle:%.3f %.3f %.3f\r\n", fAngle[0], fAngle[1], fAngle[2]);
			   	s_cDataUpdate &= ~ANGLE_UPDATE;
			   }
			   if(s_cDataUpdate & MAG_UPDATE)
			   {
			   	printf("mag:%d %d %d\r\n", sReg[HX], sReg[HY], sReg[HZ]);          //三维磁场
			   	s_cDataUpdate &= ~MAG_UPDATE;
			   }
		}
	}
	*/
}


void tly_acc_read(void)
{
	int i;
	if(s_cDataUpdate)
	{
		if(s_cDataUpdate & ACC_UPDATE)
		{
			for(i = 0; i < 3; i++)
			{
				fAcc[i] = sReg[AX+i] / 32768.0f * 16.0f;              //三维加速度
			}
			s_cDataUpdate &= ~ACC_UPDATE;
		}
	}
}


void tly_gyro_read(void)
{
	int i;
	if(s_cDataUpdate)
	{
		if(s_cDataUpdate & GYRO_UPDATE)
		{
			for(i = 0; i < 3; i++)
			{
				fGyro[i] = sReg[GX+i] / 32768.0f * 2000.0f;           //三维角速度
			}
			s_cDataUpdate &= ~GYRO_UPDATE;
		}
	}
}


void tly_angle_read(void)
{
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8,GPIO_PIN_RESET);
	int i;
	if(s_cDataUpdate) // ← 只有当这个标志位被设置时才会读取
	{
		if(s_cDataUpdate & ANGLE_UPDATE)
		{
			for(i = 0; i < 3; i++)
			{
				fAngle[i] = sReg[Roll+i] / 32768.0f * 180.0f;         //三维角度
				if(i==0) tly.x_angle=sReg[Roll+i] / 32768.0f * 180.0f;         //三维角度
				else if(i==1) tly.y_angle=sReg[Roll+i] / 32768.0f * 180.0f;
				else if(i==2) tly.z_angle=sReg[Roll+i] / 32768.0f * 180.0f;
			}
			s_cDataUpdate &= ~ANGLE_UPDATE;
		}
	}
}


void CopeCmdData(unsigned char ucData)
{
	 static unsigned char s_ucData[50], s_ucRxCnt = 0;

	 s_ucData[s_ucRxCnt++] = ucData;
	 if(s_ucRxCnt<3)return;										//Less than three data returned
	 if(s_ucRxCnt >= 50) s_ucRxCnt = 0;
	 if(s_ucRxCnt >= 3)
	 {
		 if((s_ucData[1] == '\r') && (s_ucData[2] == '\n'))
		 {
		  	s_cCmd = s_ucData[0];
			  memset(s_ucData,0,50);//
			  s_ucRxCnt = 0;
	   }
		 else
		 {
			 s_ucData[0] = s_ucData[1];
			 s_ucData[1] = s_ucData[2];
			 s_ucRxCnt = 2;
			}
	  }
}

/*
static void ShowHelp(void)          //串口打印帮助面板
{
	printf("\r\n************************	 WIT_SDK_DEMO	************************");
	printf("\r\n************************          HELP           ************************\r\n");
	printf("UART SEND:a\\r\\n   Acceleration calibration.\r\n");
	printf("UART SEND:m\\r\\n   Magnetic field calibration,After calibration send:   e\\r\\n   to indicate the end\r\n");
	printf("UART SEND:U\\r\\n   Bandwidth increase.\r\n");
	printf("UART SEND:u\\r\\n   Bandwidth reduction.\r\n");
	printf("UART SEND:B\\r\\n   Baud rate increased to 115200.\r\n");
	printf("UART SEND:b\\r\\n   Baud rate reduction to 9600.\r\n");
	printf("UART SEND:R\\r\\n   The return rate increases to 10Hz.\r\n");
	printf("UART SEND:r\\r\\n   The return rate reduction to 1Hz.\r\n");
	printf("UART SEND:C\\r\\n   Basic return content: acceleration, angular velocity, angle, magnetic field.\r\n");
	printf("UART SEND:c\\r\\n   Return content: acceleration.\r\n");
	printf("UART SEND:h\\r\\n   help.\r\n");
	printf("******************************************************************************\r\n");
}
*/

/*
static void CmdProcess(void)            //设置参数 使用串口发送对应的字母实现对应功能
{
	switch(s_cCmd)
	{
		case 'a':	
			if(WitStartAccCali() != WIT_HAL_OK) 
				printf("\r\nSet AccCali Error\r\n");
			break;
		case 'm':	
			if(WitStartMagCali() != WIT_HAL_OK) 
				printf("\r\nSet MagCali Error\r\n");
			break;
		case 'e':	
			if(WitStopMagCali() != WIT_HAL_OK)
				printf("\r\nSet MagCali Error\r\n");
			break;
		case 'u':	
			if(WitSetBandwidth(BANDWIDTH_5HZ) != WIT_HAL_OK) 
				printf("\r\nSet Bandwidth Error\r\n");
			break;
		case 'U':	
			if(WitSetBandwidth(BANDWIDTH_256HZ) != WIT_HAL_OK) 
				printf("\r\nSet Bandwidth Error\r\n");
			break;
		case 'B':	
			if(WitSetUartBaud(WIT_BAUD_115200) != WIT_HAL_OK) 
				printf("\r\nSet Baud Error\r\n");
			else 
				Usart2Init(c_uiBaud[WIT_BAUD_115200]);											
			break;
		case 'b':	
			if(WitSetUartBaud(WIT_BAUD_9600) != WIT_HAL_OK)
				printf("\r\nSet Baud Error\r\n");
			else 
				Usart2Init(c_uiBaud[WIT_BAUD_9600]);												
			break;
		case 'R':	
			if(WitSetOutputRate(RRATE_10HZ) != WIT_HAL_OK) 
				printf("\r\nSet Rate Error\r\n");
			break;
		case 'r':	
			if(WitSetOutputRate(RRATE_1HZ) != WIT_HAL_OK) 
				printf("\r\nSet Rate Error\r\n");
			break;
		case 'C':	
			if(WitSetContent(RSW_ACC|RSW_GYRO|RSW_ANGLE|RSW_MAG) != WIT_HAL_OK) 
				printf("\r\nSet RSW Error\r\n");
			break;
		case 'c':	
			if(WitSetContent(RSW_ACC) != WIT_HAL_OK) 
				printf("\r\nSet RSW Error\r\n");
			break;
		case 'h':
			ShowHelp();
			break;
	}
	s_cCmd = 0xff;
}
*/

static void SensorUartSend(uint8_t *p_data, uint32_t uiSize)
{
	HAL_UART_Transmit(&huart2, (uint8_t *)&p_data, uiSize, 0xffff);
}


static void SensorDataUpdata(uint32_t uiReg, uint32_t uiRegNum)
{
	int i;
    for(i = 0; i < uiRegNum; i++)
    {
        switch(uiReg)
        {
//            case AX:
//            case AY:
            case AZ:
				s_cDataUpdate |= ACC_UPDATE;
            break;
//            case GX:
//            case GY:
            case GZ:
				s_cDataUpdate |= GYRO_UPDATE;
            break;
//            case HX:
//            case HY:
            case HZ:
				s_cDataUpdate |= MAG_UPDATE;
            break;
//            case Roll:
//            case Pitch:
            case Yaw:
				s_cDataUpdate |= ANGLE_UPDATE;
            break;
            default:
				s_cDataUpdate |= READ_UPDATE;
			break;
        }
		uiReg++;
    }
}

/*
static void AutoScanSensor(void)
{
	int i, iRetry;
	
	for(i = 1; i < 10; i++)
	{
		Usart2Init(c_uiBaud[i]);
		iRetry = 2;
		do
		{
			s_cDataUpdate = 0;
			WitReadReg(AX, 3);
			delay_ms(100);
			if(s_cDataUpdate != 0)
			{
				printf("%d baud find sensor\r\n\r\n", c_uiBaud[i]);
				ShowHelp();
				return ;
			}
			iRetry--;
		}while(iRetry);		
	}
	printf("can not find sensor\r\n");
	printf("please check your connection\r\n");
}
*/

