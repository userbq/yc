#include "huidu.h"
#include "pid.h"
#include "motor.h"
#include "oled.h"
#include "usart.h"

extern uint8_t USART_RX_STA[4];       //接收状态标记
extern uint8_t Num;              //接收数据的当前位置
extern uint8_t USART4_RX_STA[4];
extern uint8_t Num4;
extern uint8_t USART5_RX_STA[4];
extern uint8_t Num5;
uint8_t nnn[2];



void huidu_init(void)
{
	HAL_UART_Receive_IT(&huart1, &USART_RX_STA[Num], 1);  //开启串口1接收中断
	HAL_UART_Receive_IT(&huart4, &USART4_RX_STA[Num4], 1);  //开启串口4接收中断
	HAL_UART_Receive_IT(&huart5, &USART5_RX_STA[Num5], 1);  //开启串口5接收中断
}

uint16_t Read_Data(void)
{
	uint8_t y=0;
	uint16_t Receive_data = 0;       //数据缓存区
	nnn[0]=0x57;
	nnn[1]=0x01;
	///////////////////////////数字量数值///////////////////////////////
	HAL_UART_Transmit(&huart1, (uint8_t *)&nnn, 2, 0xffff);

	while(1)
	{
		if(Num == 4)
		{
			Num = 0;
			if(USART_RX_STA[3] == 0x03)  //判断帧尾0x03,否者不赋值
			{
				Receive_data = USART_RX_STA[2];//灰度9-16号,9为低位
				Receive_data <<= 8;
				Receive_data |= USART_RX_STA[1];//灰度1-8号,1为低位

				//*Data = Receive_data;    //数字量赋值
				break;
			}
		}
		else
		{
			HAL_Delay(1);y++;
			if(y==3) { Num = 0;break; }
		}
	}
	// OLED_ShowString(2, 1, "Read OK");
	return Receive_data;
}

uint16_t Read_Data4(void)
{
	uint8_t y=0;
	uint16_t Receive_data = 0;       //数据缓存区
	nnn[0]=0x57;
	nnn[1]=0x01;
	///////////////////////////数字量数值///////////////////////////////
	HAL_UART_Transmit(&huart4, (uint8_t *)&nnn, 2, 0xffff);

	while(1)
	{
		if(Num4 == 3)
		{
			Num4 = 0;
			if(USART4_RX_STA[0] == 0x75 && USART4_RX_STA[2] == 0x02)  //判断帧头0x75和帧尾0x02,否则不赋值
			{
				Receive_data = USART4_RX_STA[1];  // 7路灰度数据（1字节）

				//*Data = Receive_data;    //数字量赋值
				break;
			}
		}
		else
		{
			HAL_Delay(1);y++;
			if(y==3) { Num4 = 0;break; }
		}
	}
	return Receive_data;
}

uint16_t Read_Data5(void)
{
	uint8_t y=0;
	uint16_t Receive_data = 0;       //数据缓存区
	nnn[0]=0x57;
	nnn[1]=0x01;
	///////////////////////////数字量数值///////////////////////////////
	HAL_UART_Transmit(&huart5, (uint8_t *)&nnn, 2, 0xffff);

	while(1)
	{
		if(Num5 == 3)
		{
			Num5 = 0;
			if(USART5_RX_STA[0] == 0x75 && USART5_RX_STA[2] == 0x02)  //判断帧头0x75和帧尾0x02,否则不赋值
			{
				Receive_data = USART5_RX_STA[1];  // 7路灰度数据（1字节）

				//*Data = Receive_data;    //数字量赋值
				break;
			}
		}
		else
		{
			HAL_Delay(1);y++;
			if(y==3) { Num5 = 0;break; }
		}
	}
	return Receive_data;
}


