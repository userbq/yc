#include "motor.h"
#include "pid.h"
#include "tim.h"
#include "oled.h"
#include "huidu.h"

void Motor_Init(void)
{
    HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_3);
    HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_4);
    HAL_TIM_PWM_Start(&htim12,TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim12,TIM_CHANNEL_2);
}

//单路电机控制函数，direction为1时正转，为2时反转，speed为占空比，范围-1000~1000
void Single_Motor(u8 selection, s16 speed)
{
    if(speed >= 0)
    {
        if(speed>900) speed=900;
        switch(selection)
        {
        case MOTOR_LEFT:
                __HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_3,0);//设置占空比
                __HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_4,speed);
            break;
        case MOTOR_RIGHT:
                __HAL_TIM_SetCompare(&htim12,TIM_CHANNEL_1,0);
                __HAL_TIM_SetCompare(&htim12,TIM_CHANNEL_2,speed);
            break;
        }
    }
    else
    {
        if(speed<-900) speed=-900;
        switch(selection)
        {
        case MOTOR_LEFT:
            __HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_3,-speed);//设置占空比
            __HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_4,-0);
            break;
        case MOTOR_RIGHT:
            __HAL_TIM_SetCompare(&htim12,TIM_CHANNEL_1,-speed);
            __HAL_TIM_SetCompare(&htim12,TIM_CHANNEL_2,-0);
            break;
        }
    }
}


void stop()
{
    __HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_3,0);//设置占空比
    __HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_4,0);
    __HAL_TIM_SetCompare(&htim12,TIM_CHANNEL_1,0);
    __HAL_TIM_SetCompare(&htim12,TIM_CHANNEL_2,0);
}

//目前在5000ms使时间上，循环了834次，频率约为166.8Hz，实际频率可能会因为PID计算和OLED显示的时间而有所波动
void zhixian(uint16_t  base_speed, uint16_t time)
{
    // OLED_ShowString(1, 1, "Start");
    uint32_t start_time = HAL_GetTick();
    // uint32_t loop_count = 0;  // 添加计数器
    // uint32_t current_time = 0;
    while ((HAL_GetTick() - start_time) < time)
    {
        PID_Output(base_speed);
        // current_time = HAL_GetTick() - start_time;
        // loop_count++;  // 记录循环次数
    }
    // OLED_ShowNum(2, 1, current_time, 5);  // 显示经过的时间
    // OLED_ShowNum(3, 1, loop_count, 5);  // 显示循环次数

}

//双线循迹直线行驶函数，使用两侧7路灰度传感器进行PID控制
void dual_zhixian(uint16_t base_speed, uint16_t time)
{
    uint32_t start_time = HAL_GetTick();
    uint32_t current_time = 0;
    while ((HAL_GetTick() - start_time) < time)
    {
        dual_PID_Output(base_speed);
        current_time = HAL_GetTick() - start_time;
    }
}

void circle_dual_go(uint16_t base_speed, uint16_t time)
{
    uint32_t start_time = HAL_GetTick();
    uint32_t current_time = 0;
    while ((HAL_GetTick() - start_time) < time)
    {
        circle_dual_PID_Output(base_speed);
        current_time = HAL_GetTick() - start_time;
    }
}
