#ifndef ENCODER_H
#define ENCODER_H

#include "main.h"

void Encoder_InitAll(void);
void Encoder_Update10ms(void);

float Encoder_GetLeftSpeedRPM(void);
float Encoder_GetRightSpeedRPM(void);
float Encoder_GetCurrentSpeedRPM(void);

int32_t Encoder_GetLeftCounterValue(void);
int32_t Encoder_GetRightCounterValue(void);
int32_t Encoder_GetLeftCounterDelta(int32_t start);
int32_t Encoder_GetRightCounterDelta(int32_t start);

void Encoder_ResetAll(void);

#endif
