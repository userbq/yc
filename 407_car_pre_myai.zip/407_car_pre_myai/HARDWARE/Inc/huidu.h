#ifndef __HUIDU_H
#define __HUIDU_H
#include "main.h"

/* 单线循迹相关函数 */
void huidu_init(void);
uint16_t Read_Data(void);
uint16_t Read_Data4(void);
uint16_t Read_Data5(void);

/* 双线循迹相关函数 */
void dual_line_init(void);
void dual_line_error_calculate(void);
void dual_line_PID_Output(int speed);

#endif
