//
// Created by yans on 2026/3/28.

#ifndef MOTOR_H
#define MOTOR_H
#include "main.h"
enum motor_direction
{
    MOTOR_FORWARD,
    MOTOR_BACKWARD,
    MOTOR_STOP
};
enum motor_selection
{
    MOTOR_LEFT,
    MOTOR_RIGHT
};
void Motor_Init(void);
void Single_Motor(u8 direction, s16 speed);
void zhixian(uint16_t  base_speed, uint16_t time);
void dual_zhixian(uint16_t base_speed, uint16_t time);
void circle_dual_go(uint16_t base_speed, uint16_t time);
void stop();
#endif
