#ifndef __OLED_H
#define __OLED_H

#include "main.h"  // 必须包含此头文件以支持 HAL 库类型和引脚定义

// --- 字体大小枚举 ---
typedef enum {
    OLED_FONT_8X16 = 0,//采用8x16点阵字体，可以显示16列，4行
    OLED_FONT_6X8//采用6x8点阵字体，可以显示21列，8行
} OLED_FontSize;

// --- 基础显示功能 ---
void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char, OLED_FontSize font);
void OLED_ShowString(uint8_t Line, uint8_t Column, char *String, OLED_FontSize font);

// --- 整数显示功能 ---
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length, OLED_FontSize font);
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length, OLED_FontSize font);
void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length, OLED_FontSize font);
void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length, OLED_FontSize font);

// --- 进阶高级功能 ---
void OLED_ShowFloat(uint8_t Line, uint8_t Column, double Number, uint8_t IntLength, uint8_t FraLength, OLED_FontSize font);
void OLED_ShowChinese(uint8_t Line, uint8_t Column, uint8_t Chinese_Index);

#endif
