# 编码器测速与算法文档

## 硬件配置

| 项目 | 左轮 | 右轮 |
|------|------|------|
| 定时器 | TIM2 CH1/CH2 (PA0/PA1) | TIM4 CH1/CH2 (PD12/PD13) |
| 编码器线数 | 13 线 | 13 线 |
| 减速比 | 44:1 | 44:1 |
| 四倍频模式 | TI12 (同时捕获 AB 相) | TI12 |
| 每圈脉冲对数 | 13 × 44 = 572 | 572 |
| 每圈计数值 | 572 × 4 = 2288 | 2288 |
| 计数器位宽 | 32 位 (ARR=0xFFFFFFFF) | 16 位 (ARR=0xFFFF) |
| 编码器极性 | -1 (反转) | +1 (正极性) |

## 测速算法

### M 法测速原理

采用 **M 法**（固定时间窗计数法）测速：

```
RPM = Δcount × (60000 / (T_ms × count_per_rev))
```

- `Δcount`：10ms 时间窗内的脉冲计数差
- `T_ms`：采样周期 = 10ms
- `count_per_rev`：每圈计数值 = 2288

代入参数：
```
RPM = Δcount × (60000 / (10 × 2288))
    = Δcount × 2.6224
```

### 计数器回绕处理

定时器计数器存在回绕问题，使用最短路径法计算有符号差值：

```c
diff = current_count - last_count;
half_modulus = (auto_reload + 1) / 2;

if (diff >= half_modulus)
    diff -= (auto_reload + 1);
else if (diff < -half_modulus)
    diff += (auto_reload + 1);
```

- 32 位计数器 (TIM2)：使用 64 位整数避免 `0xFFFFFFFF + 1` 溢出
- 结果映射到 `[-modulus/2, modulus/2)` 区间，确保取最短路径

### 零脉冲快速清零

连续 2 个采样周期无脉冲时，直接清空滤波状态：

```c
if (zero_diff_count >= 2) {
    lowpass_stage1_rpm = 0.0f;
    filtered_rpm = 0.0f;
}
```

目的：停车时避免滤波器残余尾差导致虚假速度输出。

## 双级自适应低通滤波

### 滤波结构

```
原始 RPM → [一级低通] → [二级低通] → 最终输出
```

### 自适应系数选择

根据输入与状态的差值动态切换系数：

```
|input - state| >= 18.0 RPM → 使用快速系数（降低迟滞）
|input - state| <  18.0 RPM → 使用慢速系数（压制纹波）
```

### 滤波参数

| 级数 | 快速系数 (α_fast) | 慢速系数 (α_slow) | 用途 |
|------|-------------------|-------------------|------|
| 一级 | 0.70 | 0.45 | 主滤波，响应速度阶跃 |
| 二级 | 0.30 | 0.16 | 进一步平滑，削弱量化噪声 |

### 滤波公式

```c
// 一级滤波
stage1_alpha = (|raw - stage1| >= 18.0) ? 0.70 : 0.45;
stage1 = stage1 + stage1_alpha * (raw - stage1);

// 二级滤波
stage2_alpha = (|stage1 - filtered| >= 18.0) ? 0.30 : 0.16;
filtered = filtered + stage2_alpha * (stage1 - filtered);
```

## 整车共模速度估算

### 算法逻辑

```c
if (left == 0 || right == 0 || left*right < 0)
    return 0;  // 无效：有轮静止或原地转向

return sign(left+right) * min(|left|, |right|);  // 取慢轮
```

### 设计意图

- **同向取慢轮**：打滑时快轮转速虚高，慢轮更接近真实车速
- **异号返回 0**：原地转向时整车无前进位移
- **零速返回 0**：单轮静止时速度估计不可靠

## 速度环控制

### 控制器结构

```
目标 RPM → [限幅] → [PID] → PWM 输出
                ↑
           编码器反馈
```

### 默认 PID 参数

| 参数 | 左轮 | 右轮 |
|------|------|------|
| Kp | 9.97350 | 9.94446 |
| Ki | 1.76781 | 1.78444 |
| Kd | 0 | 0 |

### 控制参数

| 参数 | 值 | 说明 |
|------|-----|------|
| 目标 RPM 上限 | ±300 | 小动力电机机械极限 |
| PWM 输出限幅 | ±5880 | 统一执行器上限 |
| 积分限幅 | 3000 | 防止积分饱和 |
| 积分分离阈值 | 60 RPM | 大误差时关闭积分 |
| 目标零速带 | 2 RPM | 压缩极低速抖动 |
| 当前零速带 | 8 RPM | 放宽静止判定 |

### 零速死区处理

当目标和当前转速都接近零时，强制停机并重置 PID：

```c
if (|target| <= 2.0 && |current| <= 8.0) {
    output = 0;
    PID_Reset();  // 清空积分/微分状态
}
```

目的：
1. 静止时编码器量化噪声 (±1 脉冲/10ms) 会持续积分
2. 极低速 PWM 低于电机启动死区，输出无效且引起抖动
3. 不清零 PID 会导致起步时积分残留产生超调

## 调用时序

```
TIM6 1ms 中断
    ↓
每 10ms (100Hz)
    ↓
Encoder_Update10ms()  ← 读取脉冲差、计算 RPM、滤波
    ↓
ChassisControl_OnControlTick10ms()
    ↓
SpeedControl_UpdateLeftPid() / UpdateRightPid()  ← 速度环 PID 计算
    ↓
Motor_SetPwm()  ← 输出 PWM
```

## 接口列表

| 接口 | 说明 |
|------|------|
| `Encoder_InitAll()` | 初始化左右编码器，启动定时器编码器模式 |
| `Encoder_Update10ms()` | 10ms 周期更新，计算滤波后的 RPM |
| `Encoder_GetLeftSpeedRPM()` | 获取左轮速度 (含极性修正) |
| `Encoder_GetRightSpeedRPM()` | 获取右轮速度 |
| `Encoder_GetCurrentSpeedRPM()` | 获取整车共模速度 |
| `Encoder_GetLeftCounterValue()` | 获取左编码器原始计数值 |
| `Encoder_GetRightCounterValue()` | 获取右编码器原始计数值 |
| `Encoder_GetLeftCounterDelta(start)` | 获取左编码器相对计数差 (带回绕) |
| `Encoder_GetRightCounterDelta(start)` | 获取右编码器相对计数差 (带回绕) |
| `Encoder_ResetAll()` | 重置所有编码器状态和滤波器 |
| `SpeedControl_Init()` | 初始化左右轮速度环 PID |
| `SpeedControl_SetStraightTargetRpm(rpm)` | 设置直行目标 (左右同速) |
| `SpeedControl_SetLeftTargetRpm(rpm)` | 设置左轮目标 (差速转向) |
| `SpeedControl_SetRightTargetRpm(rpm)` | 设置右轮目标 (差速转向) |
| `SpeedControl_UpdateLeftPid()` | 执行左轮 PID，返回 PWM |
| `SpeedControl_UpdateRightPid()` | 执行右轮 PID，返回 PWM |
| `SpeedControl_GetLeftCurrentRpm()` | 获取左轮当前转速缓存 |
| `SpeedControl_GetRightCurrentRpm()` | 获取右轮当前转速缓存 |

## 文件位置

- `user/Hardware/sensor/encoder/encoder.h` - 编码器模块头文件
- `user/Hardware/sensor/encoder/encoder.c` - 编码器模块实现
- `user/Software/control/speed_control/speed_control.h` - 速度环头文件
- `user/Software/control/speed_control/speed_control.c` - 速度环实现
- `user/Software/runtime/app_irq/app_irq.c` - 定时器中断调用入口
