#ifndef BSP_UART6_COMM_H
#define BSP_UART6_COMM_H

#include "main.h"
#include <stddef.h>
#include <stdint.h>

#define BSP_UART6_COMM_ECHO_OFF 0U
#define BSP_UART6_COMM_ECHO_BYTE 1U
#define BSP_UART6_COMM_ECHO_LINE 2U

void BspUart6Comm_Init(void);
void BspUart6Comm_RxCallback(UART_HandleTypeDef *huart);
uint8_t BspUart6Comm_ReadLine(char *out, size_t max_len);
void BspUart6Comm_SendString(const char *text);
void BspUart6Comm_SetEcho(uint8_t mode);

#endif
