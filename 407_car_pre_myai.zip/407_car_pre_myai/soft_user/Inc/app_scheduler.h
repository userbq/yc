#ifndef APP_SCHEDULER_H
#define APP_SCHEDULER_H

#include "app_task.h"

void AppScheduler_Init(void);
void AppScheduler_Run(void);
void AppScheduler_Tick1ms(void);
uint32_t AppScheduler_Now(void);

int AppScheduler_Start(AppTaskId_t id, uint16_t speed, uint16_t duration_ms);
int AppScheduler_Stop(AppTaskId_t id);
int AppScheduler_SetPeriod(AppTaskId_t id, uint16_t period_ms);
AppTaskContext_t *AppScheduler_GetTask(AppTaskId_t id);

#endif
