#ifndef INC_407_CAR_DELAY_H
#define INC_407_CAR_DELAY_H

#include "main.h"
#include <stdint.h>
#include <stdbool.h>

/* 可以创建多个独立的定时器
DelayTimer_t led_timer;
DelayTimer_t sensor_timer;
DelayTimer_t motor_timer;
*/
typedef struct {
    uint32_t start_tick;
    uint32_t interval_ms;
    bool is_running;
} DelayTimer_t;

void Delay_Init(DelayTimer_t *timer, uint32_t interval_ms);
void Delay_Start(DelayTimer_t *timer);
void Delay_Stop(DelayTimer_t *timer);
bool Delay_IsTimeout(DelayTimer_t *timer);
void Delay_Restart(DelayTimer_t *timer);
uint32_t Delay_GetElapsed(DelayTimer_t *timer);

void delay_block_ms(uint32_t ms);

#endif