//
// Created by yans on 2026/4/11.
//

#ifndef INC_407_CAR_ROUTE_H
#define INC_407_CAR_ROUTE_H
#include <stdint.h>

/**
 * @brief 循迹模式枚举，定义小车可使用的不同循迹方式
 */
typedef enum
{
	ROUTE_TRACK_SINGLE = 0,
	ROUTE_TRACK_DUAL,
	ROUTE_TRACK_CIRCLE_DUAL
} RouteTrackMode_t;

/**
 * @brief 路径动作结构体，包含完整的循迹动作信息
 */
typedef struct
{
	RouteTrackMode_t mode;
	uint16_t speed;
	uint16_t duration_ms;
} RouteAction_t;

/**
 * @brief 任务回调函数类型定义
 * @param user_data 用户自定义数据指针，可在回调中传递额外参数
 */
typedef void (*RouteTaskCallback_t)(void *user_data);

/**
 * @brief 任务类型枚举，定义路线任务支持的所有操作类型
 */
typedef enum
{
	ROUTE_TASK_TYPE_MOVE = 0,
	ROUTE_TASK_TYPE_STOP,
	ROUTE_TASK_TYPE_DELAY,
	ROUTE_TASK_TYPE_CALLBACK
} RouteTaskType_t;

/**
 * @brief 路线任务结构体，支持多种任务类型的联合体设计
 *
 * 该结构体使用联合体来存储不同类型的任务数据，节省内存空间。
 * 支持移动、停止、延时和回调四种任务类型，可实现复杂的路径规划。
 */
typedef struct
{
	RouteTaskType_t type;
	union
	{
		RouteAction_t move;
		uint16_t delay_ms;
		struct
		{
			RouteTaskCallback_t callback;
			void *user_data;
		} hook;
	} data;
} RouteTask_t;

/**
 * @brief 自动计算固定数组中的路径段数量
 * @param table 路径段数组名
 * @return 数组元素个数（uint16_t类型）
 */
#define ROUTE_SEGMENT_COUNT(table) ((uint16_t)(sizeof(table) / sizeof((table)[0])))

/**
 * @brief 一键执行路径段计划，自动计算数组长度
 * @param table 路径段数组名
 * @param mode 循迹模式
 * @param stop_between_segments 是否在每段之间停止（1=停止，0=不停止）
 * @param segment_gap_ms 段间间隔时间（毫秒）
 */
#define ROUTE_RUN_PLAN(table, mode, stop_between_segments, segment_gap_ms) \
	Route_RunSegments((table), ROUTE_SEGMENT_COUNT(table), (mode), (stop_between_segments), (segment_gap_ms))

/**
 * @brief 自动计算动作数组中的元素数量
 * @param table 动作数组名
 * @return 数组元素个数（uint16_t类型）
 */
#define ROUTE_ACTION_COUNT(table) ((uint16_t)(sizeof(table) / sizeof((table)[0])))

/**
 * @brief 一键执行动作计划，自动计算数组长度
 * @param table 动作数组名
 * @param stop_between_actions 是否在每个动作之间停止（1=停止，0=不停止）
 * @param action_gap_ms 动作间间隔时间（毫秒）
 */
#define ROUTE_RUN_ACTION_PLAN(table, stop_between_actions, action_gap_ms) \
	Route_RunActions((table), ROUTE_ACTION_COUNT(table), (stop_between_actions), (action_gap_ms))

/**
 * @brief 自动计算任务数组中的元素数量
 * @param table 任务数组名
 * @return 数组元素个数（uint16_t类型）
 */
#define ROUTE_TASK_COUNT(table) ((uint16_t)(sizeof(table) / sizeof((table)[0])))

/**
 * @brief 创建移动任务初始化器
 * @param mode 循迹模式（ROUTE_TRACK_SINGLE/ROUTE_TRACK_DUAL/ROUTE_TRACK_CIRCLE_DUAL）
 * @param speed 运动速度
 * @param duration_ms 持续时间（毫秒）
 * @return RouteTask_t 结构体初始化值
 */
#define ROUTE_TASK_MOVE(mode, speed, duration_ms) \
	{ ROUTE_TASK_TYPE_MOVE, { .move = { (mode), (speed), (duration_ms) } } }

/**
 * @brief 创建停止任务初始化器
 * @return RouteTask_t 结构体初始化值
 */
#define ROUTE_TASK_STOP() \
	{ ROUTE_TASK_TYPE_STOP, { .delay_ms = 0 } }

/**
 * @brief 创建延时任务初始化器
 * @param delay_ms 延时时间（毫秒）
 * @return RouteTask_t 结构体初始化值
 */
#define ROUTE_TASK_DELAY(delay_ms) \
	{ ROUTE_TASK_TYPE_DELAY, { .delay_ms = (delay_ms) } }

/**
 * @brief 创建回调任务初始化器
 * @param callback 回调函数指针
 * @param user_data 传递给回调函数的用户数据指针
 * @return RouteTask_t 结构体初始化值
 */
#define ROUTE_TASK_CALLBACK(callback, user_data) \
	{ ROUTE_TASK_TYPE_CALLBACK, { .hook = { (callback), (user_data) } } }

/**
 * @brief 一键执行任务计划，自动计算数组长度
 * @param table 任务数组名
 * @param stop_between_tasks 是否在每个任务之间停止（1=停止，0=不停止）
 * @param task_gap_ms 任务间间隔时间（毫秒）
 */
#define ROUTE_RUN_TASK_PLAN(table, stop_between_tasks, task_gap_ms) \
	Route_RunTasks((table), ROUTE_TASK_COUNT(table), (stop_between_tasks), (task_gap_ms))

void Route_RunActions(const RouteAction_t *actions,
					  uint16_t action_count,
					  uint8_t stop_between_actions,
					  uint16_t action_gap_ms);

void Route_RunTasks(const RouteTask_t *tasks,
				   uint16_t task_count,
				   uint8_t stop_between_tasks,
				   uint16_t task_gap_ms);

void Route_WaitSBLow(uint8_t sb_index, uint16_t speed, uint16_t delay_after_detect_ms);

void pinttai1_2();
void pingtai3_4();
#endif //INC_407_CAR_ROUTE_H