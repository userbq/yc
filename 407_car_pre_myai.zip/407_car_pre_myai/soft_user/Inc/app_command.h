#ifndef APP_COMMAND_H
#define APP_COMMAND_H

void AppCommand_Init(void);
void AppCommand_Poll(void);

#endif
