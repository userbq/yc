#ifndef __PID_H
#define __PID_H

/* 单线循迹PID */
void _err_(void);
float pid_calculate(float err_new, float Kp, float Ki, float Kd);
void PID_Output(int speed);

/* 双线循迹PID */
void dual_PID_Output(int speed);
void circle_dual_PID_Output(int speed);
#endif
