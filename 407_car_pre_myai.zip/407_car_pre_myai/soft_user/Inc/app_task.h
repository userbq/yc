#ifndef APP_TASK_H
#define APP_TASK_H

#include <stdint.h>

typedef enum {
    APP_TASK_ID_LINE = 0,
    APP_TASK_ID_DUAL_LINE,
    APP_TASK_ID_CIRCLE_DUAL,
    APP_TASK_ID_ENCODER,
    APP_TASK_ID_DISPLAY,
    APP_TASK_ID_MAX
} AppTaskId_t;

typedef enum {
    APP_TASK_STATE_IDLE = 0,
    APP_TASK_STATE_ARMING,
    APP_TASK_STATE_RUNNING,
    APP_TASK_STATE_WAITING,
    APP_TASK_STATE_DONE,
    APP_TASK_STATE_ERROR
} AppTaskState_t;

typedef struct AppTaskContext AppTaskContext_t;

typedef void (*AppTaskCallback_t)(AppTaskContext_t *ctx);

struct AppTaskContext {
    AppTaskId_t id;              // 任务ID（LINE / DUAL_LINE / CIRCLE_DUAL）
    AppTaskState_t state;        // 当前状态（IDLE / ARMING / RUNNING / DONE ...）
    uint8_t enabled;             // 是否启用
    uint16_t period_ms;          // 执行周期
    uint32_t next_run_ms;        // 下次执行的毫秒时间戳
    uint16_t speed;              // 当前速度设定
    uint16_t duration_ms;        // 总运行时长（0 = 无限）
    uint32_t started_ms;         // 启动时刻的毫秒时间戳
    int32_t error_code;          // 错误码
    AppTaskCallback_t on_enter;  // 启动回调
    AppTaskCallback_t on_tick;   // 每次周期执行的回调
    AppTaskCallback_t on_exit;   // 退出回调
};


const char *AppTask_Name(AppTaskId_t id);
const char *AppTask_StateName(AppTaskState_t state);

#endif
