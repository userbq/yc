#ifndef SPEED_CONTROL_H
#define SPEED_CONTROL_H

#include "main.h"

void SpeedControl_Init(void);

void SpeedControl_SetStraightTargetRpm(float rpm);
void SpeedControl_SetLeftTargetRpm(float rpm);
void SpeedControl_SetRightTargetRpm(float rpm);

int16_t SpeedControl_UpdateLeftPid(void);
int16_t SpeedControl_UpdateRightPid(void);

float SpeedControl_GetLeftCurrentRpm(void);
float SpeedControl_GetRightCurrentRpm(void);
float SpeedControl_GetLeftTargetRpm(void);
float SpeedControl_GetRightTargetRpm(void);

void SpeedControl_ResetPid(void);

#endif
