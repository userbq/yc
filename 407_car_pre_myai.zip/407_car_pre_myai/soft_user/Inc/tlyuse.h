#ifndef __TLYUSE_H
#define __TLYUSE_H

#include "main.h"
#include "../../HARDWARE/Inc/tly.h"

// Use -1.0f when the IMU is mounted 180 degrees reversed; use 1.0f for original mounting.
#ifndef TLYUSE_SPT_TILT_DIR
#define TLYUSE_SPT_TILT_DIR (1.0f)
#endif

float tly_err(void);
void Tly_L(float angle);
void Tly_R(float angle);
void Tly_L_pt(float angle);
void Tly_R_pt(float angle);
void tlyuse_spt(float speed);
void tlyuse_turn(float jd, uint8_t fs_mode, uint8_t wz_mode, uint16_t speed_turn);

#endif
