#ifndef __SHOW_H
#define __SHOW_H
#include "main.h"

void Show_Encoder(void);
void show_tly(void);
void show_huidu(void);
#endif