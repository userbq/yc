#include "bsp_uart6_comm.h"
#include "usart.h"

#define UART6_RX_BUFFER_SIZE 128U
#define UART6_LINE_BUFFER_SIZE 96U

static uint8_t uart6_rx_byte;
static volatile uint16_t uart6_rx_write;
static volatile uint16_t uart6_rx_read;
static char uart6_rx_buffer[UART6_RX_BUFFER_SIZE];
static volatile uint8_t uart6_echo_mode;

static uint16_t BspUart6Comm_NextIndex(uint16_t index)
{
    return (uint16_t)((index + 1U) % UART6_RX_BUFFER_SIZE);
}

void BspUart6Comm_Init(void)
{
    uart6_rx_write = 0U;
    uart6_rx_read = 0U;
    uart6_echo_mode = BSP_UART6_COMM_ECHO_OFF;
    HAL_UART_Receive_IT(&huart6, &uart6_rx_byte, 1U);
}

void BspUart6Comm_SetEcho(uint8_t mode)
{
    uart6_echo_mode = mode;
}

void BspUart6Comm_RxCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance != USART6)
    {
        return;
    }

    uint16_t next = BspUart6Comm_NextIndex(uart6_rx_write);
    if (next != uart6_rx_read)
    {
        uart6_rx_buffer[uart6_rx_write] = (char)uart6_rx_byte;
        uart6_rx_write = next;
    }

    HAL_UART_Receive_IT(&huart6, &uart6_rx_byte, 1U);
}

uint8_t BspUart6Comm_ReadLine(char *out, size_t max_len)
{
    size_t len = 0U;
    uint16_t scan;
    uint8_t found = 0U;

    if (out == 0 || max_len == 0U)
    {
        return 0U;
    }

    scan = uart6_rx_read;
    while (scan != uart6_rx_write)
    {
        if (uart6_rx_buffer[scan] == '\r' || uart6_rx_buffer[scan] == '\n')
        {
            found = 1U;
            break;
        }
        scan = BspUart6Comm_NextIndex(scan);
    }

    if (!found)
    {
        return 0U;
    }

    while (uart6_rx_read != uart6_rx_write)
    {
        char ch = uart6_rx_buffer[uart6_rx_read];
        uart6_rx_read = BspUart6Comm_NextIndex(uart6_rx_read);

        if ((uart6_echo_mode & BSP_UART6_COMM_ECHO_BYTE) != 0U)
        {
            HAL_UART_Transmit(&huart6, (uint8_t *)&ch, 1U, 5U);
        }

        if (ch == '\r' || ch == '\n')
        {
            out[len] = '\0';
            if (len > 0U && (uart6_echo_mode & BSP_UART6_COMM_ECHO_LINE) != 0U)
            {
                BspUart6Comm_SendString("ECHO ");
                BspUart6Comm_SendString(out);
                BspUart6Comm_SendString("\r\n");
            }
            return len > 0U;
        }
        if (len < max_len - 1U)
        {
            out[len++] = ch;
        }
    }

    return 0U;
}

void BspUart6Comm_SendString(const char *text)
{
    if (text == 0)
    {
        return;
    }

    const uint8_t *p = (const uint8_t *)text;
    uint16_t len = 0U;
    while (p[len] != '\0')
    {
        len++;
    }
    HAL_UART_Transmit(&huart6, (uint8_t *)p, len, 50U);
}
