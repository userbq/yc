#include "speed_control.h"
#include "encoder.h"
#include <math.h>

#define TARGET_RPM_LIMIT        300.0f
#define PWM_OUTPUT_LIMIT        900
#define INTEGRAL_LIMIT          3000.0f
#define INTEGRAL_SEP_THRESHOLD  60.0f
#define TARGET_ZERO_BAND        2.0f
#define CURRENT_ZERO_BAND       8.0f

typedef struct {
    float kp;
    float ki;
    float kd;
    float target_rpm;
    float integral;
    float last_error;
} SpeedPid_t;

static SpeedPid_t left_pid = {
    .kp = 9.97350f,
    .ki = 1.76781f,
    .kd = 0.0f,
    .target_rpm = 0.0f,
    .integral = 0.0f,
    .last_error = 0.0f,
};

static SpeedPid_t right_pid = {
    .kp = 9.94446f,
    .ki = 1.78444f,
    .kd = 0.0f,
    .target_rpm = 0.0f,
    .integral = 0.0f,
    .last_error = 0.0f,
};

static float left_current_rpm;
static float right_current_rpm;

static float clamp_float(float v, float lo, float hi)
{
    if (v > hi) return hi;
    if (v < lo) return lo;
    return v;
}

static int16_t clamp_s16(int32_t v, int16_t lo, int16_t hi)
{
    if (v > hi) return hi;
    if (v < lo) return lo;
    return (int16_t)v;
}

static void pid_reset(SpeedPid_t *pid)
{
    pid->integral = 0.0f;
    pid->last_error = 0.0f;
}

static int16_t pid_compute(SpeedPid_t *pid, float current_rpm)
{
    float target = pid->target_rpm;

    if (fabsf(target) <= TARGET_ZERO_BAND && fabsf(current_rpm) <= CURRENT_ZERO_BAND)
    {
        pid_reset(pid);
        return 0;
    }

    float error = target - current_rpm;

    if (fabsf(error) < INTEGRAL_SEP_THRESHOLD)
    {
        pid->integral += error;
        if (pid->integral > INTEGRAL_LIMIT)  pid->integral = INTEGRAL_LIMIT;
        if (pid->integral < -INTEGRAL_LIMIT) pid->integral = -INTEGRAL_LIMIT;
    }

    float d_error = error - pid->last_error;
    pid->last_error = error;

    float output = pid->kp * error + pid->ki * pid->integral + pid->kd * d_error;

    return clamp_s16((int32_t)output, -PWM_OUTPUT_LIMIT, PWM_OUTPUT_LIMIT);
}

void SpeedControl_Init(void)
{
    pid_reset(&left_pid);
    pid_reset(&right_pid);
    left_pid.target_rpm = 0.0f;
    right_pid.target_rpm = 0.0f;
    left_current_rpm = 0.0f;
    right_current_rpm = 0.0f;
}

void SpeedControl_SetStraightTargetRpm(float rpm)
{
    rpm = clamp_float(rpm, -TARGET_RPM_LIMIT, TARGET_RPM_LIMIT);
    left_pid.target_rpm = rpm;
    right_pid.target_rpm = rpm;
}

void SpeedControl_SetLeftTargetRpm(float rpm)
{
    left_pid.target_rpm = clamp_float(rpm, -TARGET_RPM_LIMIT, TARGET_RPM_LIMIT);
}

void SpeedControl_SetRightTargetRpm(float rpm)
{
    right_pid.target_rpm = clamp_float(rpm, -TARGET_RPM_LIMIT, TARGET_RPM_LIMIT);
}

int16_t SpeedControl_UpdateLeftPid(void)
{
    left_current_rpm = Encoder_GetLeftSpeedRPM();
    return pid_compute(&left_pid, left_current_rpm);
}

int16_t SpeedControl_UpdateRightPid(void)
{
    right_current_rpm = Encoder_GetRightSpeedRPM();
    return pid_compute(&right_pid, right_current_rpm);
}

float SpeedControl_GetLeftCurrentRpm(void)
{
    return left_current_rpm;
}

float SpeedControl_GetRightCurrentRpm(void)
{
    return right_current_rpm;
}

float SpeedControl_GetLeftTargetRpm(void)
{
    return left_pid.target_rpm;
}

float SpeedControl_GetRightTargetRpm(void)
{
    return right_pid.target_rpm;
}

void SpeedControl_ResetPid(void)
{
    pid_reset(&left_pid);
    pid_reset(&right_pid);
}
