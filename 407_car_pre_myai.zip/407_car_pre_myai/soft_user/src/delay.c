#include "delay.h"

void Delay_Init(DelayTimer_t *timer, uint32_t interval_ms)
{
    if(timer == NULL) return;

    timer->start_tick = 0;
    timer->interval_ms = interval_ms;
    timer->is_running = false;
}

void Delay_Start(DelayTimer_t *timer)
{
    if(timer == NULL) return;

    timer->start_tick = HAL_GetTick();
    timer->is_running = true;
}

void Delay_Stop(DelayTimer_t *timer)
{
    if(timer == NULL) return;

    timer->is_running = false;
}

bool Delay_IsTimeout(DelayTimer_t *timer)
{
    if(timer == NULL || !timer->is_running)
    {
        return false;
    }

    uint32_t current_tick = HAL_GetTick();
    uint32_t elapsed;

    if(current_tick >= timer->start_tick)
    {
        elapsed = current_tick - timer->start_tick;
    }
    else
    {
        elapsed = (UINT32_MAX - timer->start_tick) + current_tick + 1;
    }

    return (elapsed >= timer->interval_ms);
}

void Delay_Restart(DelayTimer_t *timer)
{
    if(timer == NULL) return;

    timer->start_tick = HAL_GetTick();
}

uint32_t Delay_GetElapsed(DelayTimer_t *timer)
{
    if(timer == NULL) return 0;

    uint32_t current_tick = HAL_GetTick();

    if(current_tick >= timer->start_tick)
    {
        return current_tick - timer->start_tick;
    }
    else
    {
        return (UINT32_MAX - timer->start_tick) + current_tick + 1;
    }
}

void delay_block_ms(uint32_t ms)
{
    if(ms == 0) return;

    uint32_t tick_start = HAL_GetTick();
    uint32_t tick_end = tick_start + ms;

    if(tick_end >= tick_start)
    {
        while(HAL_GetTick() < tick_end)
        {
        }
    }
    else
    {
        while(HAL_GetTick() >= tick_start)
        {
        }
        while(HAL_GetTick() < tick_end)
        {
        }
    }
}








// #include "delay.h"
// #include "main.h"
// #include "stdbool.h"
// uint32_t start_time;
// uint32_t elapsed_time;
//
// void time_record(void)
// {
//     start_time = HAL_GetTick();
// }
//
// uint32_t time_get(void)
// {
//     elapsed_time = HAL_GetTick() - start_time;
//     return elapsed_time;
// }
//
// bool time_arrive(uint32_t target_time)
// {
//     if (time_get() < target_time) return 0;
//         return 1;
//
// }
