#include "app_command.h"
#include "app_scheduler.h"
#include "bsp_uart6_comm.h"
#include <stdio.h>

#define APP_COMMAND_LINE_SIZE 96U
#define APP_COMMAND_REPLY_SIZE 128U

static char command_line[APP_COMMAND_LINE_SIZE];
static char command_reply[APP_COMMAND_REPLY_SIZE];

static int AppCommand_ParseMode(char mode, AppTaskId_t *id)
{
    if (id == 0)
    {
        return -1;
    }

    if (mode >= 'a' && mode <= 'z')
    {
        mode = (char)(mode - 'a' + 'A');
    }

    if (mode == 'L')
    {
        *id = APP_TASK_ID_LINE;
        return 0;
    }
    if (mode == 'D')
    {
        *id = APP_TASK_ID_DUAL_LINE;
        return 0;
    }
    if (mode == 'C')
    {
        *id = APP_TASK_ID_CIRCLE_DUAL;
        return 0;
    }

    return -1;
}

static int AppCommand_ParseFrame(const char *line,
                                 char *mode,
                                 uint16_t *speed,
                                 uint16_t *time_ms)
{
    unsigned long speed_ul = 0UL;
    unsigned long time_ul = 0UL;
    char mode_local = 0;
    char tail = 0;
    int matched;

    if (line == 0 || mode == 0 || speed == 0 || time_ms == 0)
    {
        return -1;
    }

    matched = sscanf(line, " [ %c , %lu , %lu ] %c", &mode_local, &speed_ul, &time_ul, &tail);
    if (matched != 3)
    {
        return -1;
    }
    if (speed_ul > 65535UL || time_ul > 65535UL)
    {
        return -1;
    }

    *mode = mode_local;
    *speed = (uint16_t)speed_ul;
    *time_ms = (uint16_t)time_ul;
    return 0;
}

static void AppCommand_SendOk(const char *message)
{
    snprintf(command_reply, sizeof(command_reply), "OK %s\r\n", message);
    BspUart6Comm_SendString(command_reply);
}

static void AppCommand_SendErr(const char *message)
{
    snprintf(command_reply, sizeof(command_reply), "ERR %s\r\n", message);
    BspUart6Comm_SendString(command_reply);
}

static void AppCommand_HandleFrame(const char *line)
{
    AppTaskId_t id;
    char mode;
    uint16_t speed;
    uint16_t time_ms;

    if (AppCommand_ParseFrame(line, &mode, &speed, &time_ms) != 0)
    {
        AppCommand_SendErr("BAD_FRAME");
        return;
    }

    if (AppCommand_ParseMode(mode, &id) != 0)
    {
        AppCommand_SendErr("BAD_MODE");
        return;
    }

    if (AppScheduler_Start(id, speed, time_ms) != 0)
    {
        AppCommand_SendErr("START_FAIL");
        return;
    }

    snprintf(command_reply,
             sizeof(command_reply),
             "OK [%c,%u,%u] TASK=%s\r\n",
             mode,
             speed,
             time_ms,
             AppTask_Name(id));
    BspUart6Comm_SendString(command_reply);
}

static void AppCommand_Dispatch(char *line)
{
    if (line == 0 || line[0] == '\0')
    {
        return;
    }

    if (line[0] == '[')
    {
        AppCommand_HandleFrame(line);
        return;
    }

    if (line[0] == 'P' && line[1] == 'I' && line[2] == 'N' && line[3] == 'G' && line[4] == '\0')
    {
        AppCommand_SendOk("PONG");
        return;
    }

    AppCommand_SendErr("BAD_CMD");
}

void AppCommand_Init(void)
{
    BspUart6Comm_SendString("OK BOOT PROTO=[a,b,c]\r\n");
}

void AppCommand_Poll(void)
{
    while (BspUart6Comm_ReadLine(command_line, sizeof(command_line)))
    {
        AppCommand_Dispatch(command_line);
    }
}
