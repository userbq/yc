//
// Created by yans on 2026/4/4.
//
#include "myflash.h"
#include "main.h"

/**
 *@功能：从内部Flash读取指定字节数据
 *@参数1：ReadAddress：数据起始地址
 *@参数2：*data：      读取到的数据缓存首地址
 *@参数3：length：     读取字节个数
 */
void ReadFlashData(uint32_t ReadAddress, uint8_t *data, uint32_t length)
{
    for(uint32_t i=0;i<length;i++)
    {
        data[i]=*(uint8_t*)(ReadAddress+i); //读取数据
    }
}
