#include "main.h"
#include "PID.h"
#include "motor.h"
#include "huidu.h"
#include <math.h>
uint16_t Temp;
uint16_t wheel_err = 3;
float err = 0;

/* 双线循迹全局变量 */
float dual_line_err = 0;              // 双线总误差
float left_line_err = 0;              // 左侧白线误差
float right_line_err = 0;             // 右侧白线误差
uint8_t left_line_detected = 0;       // 左侧线检测标志
uint8_t right_line_detected = 0;      // 右侧线检测标志

//单线PID参数
struct PID
{
	float kp;
	float ki;
	float kd;
};
typedef struct PID _PID;

_PID pid =
{
	.kp = 22,
	.ki = 0,
	.kd = 8,
};

/* 双线PID参数 */
struct Dual_Line_PID
{
    float kp;
    float ki;
    float kd;
    float left_weight;    // 左侧权重
    float right_weight;   // 右侧权重
    float max_adjust;     // 纠偏输出限幅
    float min_adjust;     // 有偏差时的最小纠偏输出
    float min_err_active; // 启用最小纠偏的误差阈值
};


struct Dual_Line_PID dual_pid =
{
    .kp = 26,
    .ki = 0,
    .kd = 10,
    .left_weight = 1.0f,
    .right_weight = 1.0f,
    .max_adjust = 300.0f,
    .min_adjust = 30.0f,
    .min_err_active = 0.12f,
};

/* 圆环双线PID参数 */
struct Circle_Dual_Line_PID
{
    float kp;
    float ki;
    float kd;
    float turn_offset;  // 基础转弯差速（正值：左转，负值：右转）
};

struct Circle_Dual_Line_PID circle_dual_pid =
{
    .kp = 30,  // 更高的kp用于圆环更强的转向响应
    .ki = 0,
    .kd = 8,
    .turn_offset = 10,  // 基础左转差速，可根据圆环方向调整正负
};

static float clamp_float(float value, float min_v, float max_v)
{
    if (value > max_v)
    {
        return max_v;
    }
    if (value < min_v)
    {
        return min_v;
    }
    return value;
}

// 大误差时保证至少有一部分纠偏扭矩，避免“有误差但带不动”
static float apply_dual_adjust_shape(float adjust, float err_abs)
{
    adjust = clamp_float(adjust, -dual_pid.max_adjust, dual_pid.max_adjust);

    if ((err_abs > dual_pid.min_err_active) && (fabsf(adjust) < dual_pid.min_adjust))
    {
        adjust = (adjust >= 0.0f) ? dual_pid.min_adjust : -dual_pid.min_adjust;
    }
    return adjust;
}



static float pid_calculate_with_state(float err_new, float Kp, float Ki, float Kd, float *err_last)
{
    // float integral = integral + err_new;
    float voltage = Kp * err_new - Kd * (err_new - *err_last);

    *err_last = err_new;

    return voltage;
}

float pid_calculate(float err_new, float Kp, float Ki, float Kd)//(err_new - err_last)应该是负数，Kp为正值，Ki为0
{
		static float err_last = 0;
    return pid_calculate_with_state(err_new, Kp, Ki, Kd, &err_last);
}

void _err_(void)
{
	Temp=Read_Data();
	switch(Temp)															//1111111
	{  																				//65432109 87654321
		case 0xFE7F:		err =0;   	break;      //11111110 01111111		//正中间位置                                      		//65432109 87654321
		case 0xFEFF:		err =0.4; 	break;      //11111110 11111111
		case 0xFF7F:		err =-0.4;	break;      //11111111 01111111
		case 0xFCFF:		err =0.7; 	break;      //11111100 11111111
		case 0xFF3F:		err =-0.7;	break;      //11111111 00111111
		case 0xFDFF:		err =0.9; 	break;      //11111101 11111111
		case 0xFFBF:		err =-0.9;	break;      //11111111 10111111
		case 0xF9FF:		err =1;   	break;      //11111001 11111111
		case 0xFF9F:		err =-1;  	break;      //11111111 10011111
		case 0xFBFF:		err =1.2; 	break;      //11111011 11111111
		case 0xFFDF:		err =-1.2;	break;      //11111111 11011111
		case 0xF3FF:		err =1.4; 	break;      //11110011 11111111
		case 0xFFCF:		err =-1.4;	break;      //11111111 11001111
		case 0xF7FF:		err =1.6; 	break;      //11110111 11111111
		case 0xFFEF:		err =-1.6;	break;      //11111111 11101111
		case 0xE7FF:		err =1.8; 	break;      //11100111 11111111
		case 0xFFE7:		err =-1.8;	break;      //11111111 11100111
		case 0xEFFF:		err =2;   	break;      //11101111 11111111
		case 0xFFF7:		err =-2;  	break;      //11111111 11110111
		case 0xCFFF:		err =2.2; 	break;      //11001111 11111111
		case 0xFFF3:		err =-2.2;	break;      //11111111 11110011
		case 0xDFFF:		err =2.4; 	break;      //11011111 11111111
		case 0xFFFB:		err =-2.4;	break;      //11111111 11111011
		case 0x9FFF:		err =2.6; 	break;      //10011111 11111111
		case 0xFFF9:		err =-2.6;	break;      //11111111 11111001
		case 0xBFFF:		err =2.8; 	break;      //10111111 11111111
		case 0xFFFD:		err =-2.8;	break;      //11111111 11111101
		case 0x3FFF:		err =3; 	break;      //00111111 11111111
		case 0xFFFC:		err =-3;  	break;      //11111111 11111100
		case 0x7FFF:		err =3.4; 	break;      //01111111 11111111
		case 0xFFFE:		err =-3.4;	break;      //11111111 11111110
		default :			break;
    }
}

void PID_Output(int speed)
{
  static float single_line_err_last = 0;
	_err_();
  float pid_adjust = pid_calculate_with_state(err, pid.kp, 0, pid.kd, &single_line_err_last);
  Single_Motor(MOTOR_LEFT, speed + pid_adjust+wheel_err);
  Single_Motor(MOTOR_RIGHT, speed - pid_adjust);

}

// 双线循迹PID输出函数，仿照PID_Output的结构
void dual_PID_Output(int speed)
{
  static float dual_line_err_last = 0;
	dual_line_error_calculate();  // 计算双线误差
  float pid_adjust = pid_calculate_with_state(dual_line_err, dual_pid.kp, dual_pid.ki, dual_pid.kd, &dual_line_err_last);
  pid_adjust = apply_dual_adjust_shape(pid_adjust, fabsf(dual_line_err));
  Single_Motor(MOTOR_LEFT, speed + pid_adjust);
  Single_Motor(MOTOR_RIGHT, speed - pid_adjust);
}

/* ========== 双线循迹相关函数实现 ========== */

/**
 * @brief 读取双线数据（两个7路传感器）
 * @retval 包含两个7路传感器数据的结构体
 * @note 左侧传感器通过串口4读取，右侧传感器通过串口5读取
 */
typedef struct {
    uint16_t left_sensor_data;   // 左侧7路灰度传感器数据（串口4）
    uint16_t right_sensor_data;  // 右侧7路灰度传感器数据（串口5）
} Dual_Sensor_Data;

static Dual_Sensor_Data Read_Dual_Line_Data(void)
{
    Dual_Sensor_Data data;
    data.left_sensor_data = Read_Data4();   // 读取左侧传感器
    data.right_sensor_data = Read_Data5();  // 读取右侧传感器
    return data;
}

/**
 * @brief 7路灰度传感器误差计算（单侧）
 * @param sensor_data 7路传感器的8位数据
 * @retval 误差值，范围约 -3.4 ~ +3.4
 * @note 仿照原有_err_()函数的switch结构，但适配7路传感器
 */
static float calculate_single_side_error(uint8_t sensor_data)
{
    // 直接使用8位数据（7路灰度传感器）
    uint8_t data_7bit = sensor_data;  // 直接用

    switch(data_7bit)
    {
        // 7路传感器的误差映射（中间为0，向左为负，向右为正）
        // 假设7路传感器从左到右为bit6~bit0，1表示没有检测到线，0表示检测到线
        case 0x7F:  return 999.0f; // 1111111 - 所有传感器都没有检测到线
        case 0x77:  return 0;     // 1110111 - 正中间
        case 0x73:  return 0.4f;   // 1110011
        case 0x7B:  return -0.4f;  // 1111011
        case 0x67:  return 0.7f;   // 1100111
        case 0x7D:  return -0.7f;  // 1111101
        case 0x6F:  return 0.9f;   // 1101111
        case 0x7E:  return -0.9f;  // 1111110
        case 0x5F:  return 1.2f;   // 1011111
        case 0x4F:  return 1.6f;   // 1001111
        case 0x3F:  return 2.0f;   // 0111111
        case 0x1F:  return 2.4f;   // 0011111
        default:    return 999.0f; // 未识别的其他情况，返回大值表示无效数据
    }
}

/**
 * @brief 双线误差计算
 * @note 根据两侧7路灰度传感器数据计算车身总误差
 *
 * 算法说明：
 * 1. 分别计算左右两侧传感器的误差值
 * 2. 如果两侧都检测到线：总误差 = (左侧误差 + 右侧误差) / 2
 * 3. 如果只有一侧检测到线：使用该侧误差进行纠正
 * 4. 如果都没检测到：保持上一次误差值
 */
void dual_line_error_calculate(void)
{
    Dual_Sensor_Data sensor_data;
    float temp_left_err = 0;
    float temp_right_err = 0;

    // 读取两个传感器数据
    sensor_data = Read_Dual_Line_Data();

    // 计算左侧误差
    temp_left_err = calculate_single_side_error(sensor_data.left_sensor_data);
    if(temp_left_err < 900.0f)  // 有效数据
    {
        left_line_err = temp_left_err;
        left_line_detected = 1;
    }
    else
    {
        left_line_detected = 0;
    }

    // 计算右侧误差
    temp_right_err = calculate_single_side_error(sensor_data.right_sensor_data);
    if(temp_right_err < 900.0f)  // 有效数据
    {
        right_line_err = temp_right_err;
        right_line_detected = 1;
    }
    else
    {
        right_line_detected = 0;
    }

    // 右侧传感器通常为镜像安装，先统一到“同一纠偏方向”再融合
    float normalized_left_err = left_line_err;
    float normalized_right_err = -right_line_err;

    // 合并两侧误差计算总误差
    if(left_line_detected && right_line_detected)
    {
        // 两侧都检测到线：加权平均
        float weight_sum = dual_pid.left_weight + dual_pid.right_weight;
        if((weight_sum > -0.001f) && (weight_sum < 0.001f))
        {
            weight_sum = 1.0f;
        }
        dual_line_err = (normalized_left_err * dual_pid.left_weight + normalized_right_err * dual_pid.right_weight) / weight_sum;
    }
    else if(left_line_detected)
    {
        // 只有左侧检测到线
        dual_line_err = normalized_left_err;
    }
    else if(right_line_detected)
    {
        // 只有右侧检测到线
        dual_line_err = normalized_right_err;
    }
    else
    {
        // 两侧都没检测到：保持上次误差，避免控制量瞬间掉为0
    }
}

// 圆环双线循迹PID输出函数，包含基础转弯差速 + PID微调
void circle_dual_PID_Output(int speed)
{
	static float circle_dual_err_last = 0;
    dual_line_error_calculate();  // 计算双线误差
    float pid_adjust = pid_calculate_with_state(dual_line_err, circle_dual_pid.kp, circle_dual_pid.ki, circle_dual_pid.kd, &circle_dual_err_last);

    // 基础转弯差速 + PID微调
    Single_Motor(MOTOR_LEFT, speed - circle_dual_pid.turn_offset + pid_adjust+wheel_err);
    Single_Motor(MOTOR_RIGHT, speed + circle_dual_pid.turn_offset - pid_adjust);
}
