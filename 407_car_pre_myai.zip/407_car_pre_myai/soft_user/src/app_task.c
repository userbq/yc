#include "app_task.h"

const char *AppTask_Name(AppTaskId_t id)
{
    switch (id)
    {
    case APP_TASK_ID_LINE: return "LINE";// 直线任务line
    case APP_TASK_ID_DUAL_LINE: return "DUAL";// 双线任务dual_line
    case APP_TASK_ID_CIRCLE_DUAL: return "CIRCLE";// 圆环双线任务circle_dual
    case APP_TASK_ID_DISPLAY: return "DISP";// 显示任务display
    default: return "UNKNOWN";
    }
}

const char *AppTask_StateName(AppTaskState_t state)
{
    switch (state)
    {
    case APP_TASK_STATE_IDLE: return "IDLE";
    case APP_TASK_STATE_ARMING: return "ARMING";
    case APP_TASK_STATE_RUNNING: return "RUNNING";
    case APP_TASK_STATE_WAITING: return "WAITING";
    case APP_TASK_STATE_DONE: return "DONE";
    case APP_TASK_STATE_ERROR: return "ERROR";
    default: return "UNKNOWN";
    }
}
