#include "app_scheduler.h"
#include "motor.h"
#include "pid.h"
#include "encoder.h"
#include "speed_control.h"
#include "../Inc/show.h"

#define APP_TASK_DEFAULT_PERIOD_MS 20U//当前任务周期，即每20ms调用一次任务的on_tick函数
#define APP_TASK_MIN_PERIOD_MS 5U
#define APP_TASK_MAX_PERIOD_MS 1000U
#define APP_TASK_DEFAULT_SPEED 150U//默认速度
#define APP_TASK_DEFAULT_DURATION_MS 0U//默认持续时间，0表示无限持续
#define APP_TASK_DISPLAY_PERIOD_MS 100U//OLED显示刷新周期 100ms = 10Hz
#define APP_TASK_ENCODER_PERIOD_MS 10U//编码器采样周期 10ms = 100Hz

static uint32_t app_ms_tick;
static uint32_t app_last_hal_tick;


/*ctx每个循迹任务有一个独立的 AppTaskContext_t 实例（存在 app_scheduler.c 的 app_tasks[] 数组里），
ctx 就是指向它的指针。任务回调通过它能拿到自己的一切运行时状态。
换句话说，ctx 就是一个任务自己的"档案袋"，所有跟这个任务有关的信息都在里面。*/
static void AppTask_LineTick(AppTaskContext_t *ctx);
static void AppTask_DualLineTick(AppTaskContext_t *ctx);
static void AppTask_CircleDualTick(AppTaskContext_t *ctx);
static void AppTask_EncoderTick(AppTaskContext_t *ctx);
static void AppTask_StopOnExit(AppTaskContext_t *ctx);
static void AppTask_DisplayTick(AppTaskContext_t *ctx);

static AppTaskContext_t app_tasks[APP_TASK_ID_MAX] = {
    {
        .id = APP_TASK_ID_LINE,
        .state = APP_TASK_STATE_IDLE,
        .period_ms = APP_TASK_DEFAULT_PERIOD_MS,
        .speed = APP_TASK_DEFAULT_SPEED,
        .duration_ms = APP_TASK_DEFAULT_DURATION_MS,
        .on_tick = AppTask_LineTick,
        .on_exit = AppTask_StopOnExit,
    },
    {
        .id = APP_TASK_ID_DUAL_LINE,
        .state = APP_TASK_STATE_IDLE,
        .period_ms = APP_TASK_DEFAULT_PERIOD_MS,
        .speed = APP_TASK_DEFAULT_SPEED,
        .duration_ms = APP_TASK_DEFAULT_DURATION_MS,
        .on_tick = AppTask_DualLineTick,
        .on_exit = AppTask_StopOnExit,
    },
    {
        .id = APP_TASK_ID_CIRCLE_DUAL,
        .state = APP_TASK_STATE_IDLE,
        .period_ms = APP_TASK_DEFAULT_PERIOD_MS,
        .speed = APP_TASK_DEFAULT_SPEED,
        .duration_ms = APP_TASK_DEFAULT_DURATION_MS,
        .on_tick = AppTask_CircleDualTick,
        .on_exit = AppTask_StopOnExit,
    },
    {
        .id = APP_TASK_ID_ENCODER,
        .state = APP_TASK_STATE_IDLE,
        .period_ms = APP_TASK_ENCODER_PERIOD_MS,
        .speed = 0,
        .duration_ms = 0U,
        .on_tick = AppTask_EncoderTick,
        .on_exit = 0,
    },
    {
        .id = APP_TASK_ID_DISPLAY,
        .state = APP_TASK_STATE_IDLE,
        .period_ms = APP_TASK_DISPLAY_PERIOD_MS,
        .speed = 0,
        .duration_ms = APP_TASK_DEFAULT_DURATION_MS,
        .on_tick = AppTask_DisplayTick,
        .on_exit = 0,
    },
};

static uint16_t AppScheduler_ClampPeriod(uint16_t period_ms)
{
    if (period_ms < APP_TASK_MIN_PERIOD_MS)
    {
        return APP_TASK_MIN_PERIOD_MS;
    }
    if (period_ms > APP_TASK_MAX_PERIOD_MS)
    {
        return APP_TASK_MAX_PERIOD_MS;
    }
    return period_ms;
}

static int AppScheduler_IsValidTask(AppTaskId_t id)
{
    return id < APP_TASK_ID_MAX;
}
// 运行单步任务逻辑，适用于单线、双线和圆环双线任务，通过传入不同的pid_output函数实现不同的控制逻辑
static void AppTask_RunLineStep(AppTaskContext_t *ctx, void (*pid_output)(int))
{
    uint32_t elapsed_ms = AppScheduler_Now() - ctx->started_ms;

    if (ctx->state == APP_TASK_STATE_ARMING)
    {
        ctx->state = APP_TASK_STATE_RUNNING;
    }

    if (ctx->duration_ms > 0U && elapsed_ms >= ctx->duration_ms)
    {
        ctx->state = APP_TASK_STATE_DONE;
        ctx->enabled = 0U;
        if (ctx->on_exit != 0)
        {
            ctx->on_exit(ctx);
        }
        return;
    }

    if (ctx->state == APP_TASK_STATE_RUNNING)
    {
        pid_output(ctx->speed);
    }
}

static void AppTask_LineTick(AppTaskContext_t *ctx)
{
    AppTask_RunLineStep(ctx, PID_Output);
}

static void AppTask_DualLineTick(AppTaskContext_t *ctx)
{
    AppTask_RunLineStep(ctx, dual_PID_Output);
}

static void AppTask_CircleDualTick(AppTaskContext_t *ctx)
{
    AppTask_RunLineStep(ctx, circle_dual_PID_Output);
}

static void AppTask_StopOnExit(AppTaskContext_t *ctx)
{
    (void)ctx;
    stop();
}

static void AppTask_EncoderTick(AppTaskContext_t *ctx)
{
    (void)ctx;
    Encoder_Update10ms();
}

static void AppTask_DisplayTick(AppTaskContext_t *ctx)
{
    (void)ctx;
    show_tly();
    Show_Encoder();
}

void AppScheduler_Init(void)
{

    app_ms_tick = HAL_GetTick();
    app_last_hal_tick = app_ms_tick;
    for (uint8_t i = 0; i < APP_TASK_ID_MAX; i++)
    {
        app_tasks[i].enabled = 0U;
        app_tasks[i].state = APP_TASK_STATE_IDLE;
        app_tasks[i].next_run_ms = app_ms_tick;
        app_tasks[i].error_code = 0;
    }
}

void AppScheduler_Run(void)
{
    uint32_t hal_now = HAL_GetTick();
    if (hal_now != app_last_hal_tick)
    {
        app_ms_tick += hal_now - app_last_hal_tick;
        app_last_hal_tick = hal_now;
    }

    uint32_t now = AppScheduler_Now();

    for (uint8_t i = 0; i < APP_TASK_ID_MAX; i++)
    {
        AppTaskContext_t *ctx = &app_tasks[i];
        if (!ctx->enabled || ctx->on_tick == 0)
        {
            continue;
        }

        if ((int32_t)(now - ctx->next_run_ms) >= 0)
        {
            ctx->next_run_ms += ctx->period_ms;
            ctx->on_tick(ctx);
        }
    }
}

void AppScheduler_Tick1ms(void)
{
    app_ms_tick++;
    app_last_hal_tick = HAL_GetTick();
}

uint32_t AppScheduler_Now(void)
{
    return app_ms_tick;
}

int AppScheduler_Start(AppTaskId_t id, uint16_t speed, uint16_t duration_ms)
{
    if (!AppScheduler_IsValidTask(id))
    {
        return -1;
    }

    AppTaskContext_t *ctx = &app_tasks[id];
    ctx->enabled = 1U;
    ctx->state = APP_TASK_STATE_ARMING;
    ctx->speed = speed;
    ctx->duration_ms = duration_ms;
    ctx->started_ms = AppScheduler_Now();
    ctx->next_run_ms = ctx->started_ms;
    ctx->error_code = 0;

    if (ctx->on_enter != 0)
    {
        ctx->on_enter(ctx);
    }
    return 0;
}

int AppScheduler_Stop(AppTaskId_t id)
{
    if (!AppScheduler_IsValidTask(id))
    {
        return -1;
    }

    AppTaskContext_t *ctx = &app_tasks[id];
    ctx->enabled = 0U;
    ctx->state = APP_TASK_STATE_IDLE;
    if (ctx->on_exit != 0)
    {
        ctx->on_exit(ctx);
    }
    return 0;
}

int AppScheduler_SetPeriod(AppTaskId_t id, uint16_t period_ms)
{
    if (!AppScheduler_IsValidTask(id))
    {
        return -1;
    }

    app_tasks[id].period_ms = AppScheduler_ClampPeriod(period_ms);
    app_tasks[id].next_run_ms = AppScheduler_Now() + app_tasks[id].period_ms;
    return 0;
}

AppTaskContext_t *AppScheduler_GetTask(AppTaskId_t id)
{
    if (!AppScheduler_IsValidTask(id))
    {
        return 0;
    }
    return &app_tasks[id];
}
