#include "../Inc/show.h"
#include "huidu.h"
#include "oled.h"
#include "encoder.h"
#include "tly.h"
#include "math.h"
#include "wit_c_sdk.h"

void Show_Encoder(void)
{
    float left_rpm = Encoder_GetLeftSpeedRPM();
    float right_rpm = Encoder_GetRightSpeedRPM();

    OLED_ShowString(2, 1, "L:", OLED_FONT_6X8);
    OLED_ShowFloat(2, 3, left_rpm, 3, 1, OLED_FONT_6X8);
    OLED_ShowString(2, 13, "R:", OLED_FONT_6X8);
    OLED_ShowFloat(2, 15, right_rpm, 3, 1, OLED_FONT_6X8);

    int32_t left_cnt = Encoder_GetLeftCounterValue();
    int32_t right_cnt = Encoder_GetRightCounterValue();

    OLED_ShowString(3, 1, "L:", OLED_FONT_6X8);
    OLED_ShowSignedNum(3, 3, left_cnt, 5, OLED_FONT_6X8);
    OLED_ShowString(3, 12, "R:", OLED_FONT_6X8);
    OLED_ShowSignedNum(3, 14, right_cnt, 5, OLED_FONT_6X8);
}

// ... existing code ...

void show_tly(void)
{
    extern int16_t sReg[REGSIZE];

    // 先读取角度（会更新 fAngle 和 tly 结构体）
    tly_angle_read();
    // 显示三个轴的角度
    OLED_ShowString(1, 1, "X:", OLED_FONT_6X8);
    OLED_ShowString(1, 11, "Z:", OLED_FONT_6X8);
    OLED_ShowFloat(1, 13, tly.x_angle, 3, 2, OLED_FONT_6X8);
    OLED_ShowFloat(1, 3, tly.z_angle, 3, 2, OLED_FONT_6X8);
}

/*显示三各灰度的值*/
void show_huidu(void)
{
    uint16_t data1 = Read_Data();
    uint16_t data2 = Read_Data4();
    uint16_t data3 = Read_Data5();
    OLED_ShowHexNum(1, 1, data1, 4, OLED_FONT_6X8);
    OLED_ShowHexNum(2, 1, data2, 4, OLED_FONT_6X8);
    OLED_ShowHexNum(3, 1, data3, 4, OLED_FONT_6X8);
}
