//
// Created by yans on 2026/4/11.
//
#include "main.h"
#include "route.h"
#include "motor.h"
#include "pid.h"



void pinttai1_2()
{

}


void pingtai3_4()
{
    // Example: configure all straight segments in one table.
    static const RouteAction_t straight_plan1[] = {
        { ROUTE_TRACK_SINGLE, 150, 1000 },
        { ROUTE_TRACK_SINGLE, 250, 6000 },
        { ROUTE_TRACK_SINGLE, 200, 2000 },
    }                                                                                                                                                                                                                                      ;
    ROUTE_RUN_ACTION_PLAN(straight_plan1, 0, 0);
    //
    // Route_WaitSBLow(1, 150, 150);
    // stop();
    // HAL_Delay(100);
    // Tly_L_pt(90);
    //
    // zhixian(200,2500);
    //
    // while (1)
    // {
    //     PID_Output(150);
    //     if (HAL_GPIO_ReadPin(SB_MR_GPIO_Port,SB_MR_Pin) == 0)
    //     {
    //         stop();
    //         break;
    //     }
    // }
    // HAL_Delay(100);
    // Tly_R_pt(90);
    //
    // zhixian(200,500);
    //
    // while (1)
    // {
    //     PID_Output(150);
    //     if (HAL_GPIO_ReadPin(SB_MR_GPIO_Port,SB_MR_Pin) == 0)
    //     {
    //         HAL_Delay(700);
    //         stop();
    //         break;
    //     }
    // }
    // HAL_Delay(100);
    // Tly_R_pt(130);

    // circle_dual_go(150, 5000);
    stop();
}

static GPIO_PinState Route_ReadSB(uint8_t sb_index)
{
    switch (sb_index)
    {
    case 0: return SB0;
    case 1: return SB1;
    case 2: return SB2;
    case 3: return SB3;
    case 4: return SB4;
    case 5: return SB5;
    default: return GPIO_PIN_SET;
    }
}

void Route_WaitSBLow(uint8_t sb_index, uint16_t speed, uint16_t delay_after_detect_ms)
{
    if (sb_index > 5)
    {
        return;
    }

    while (Route_ReadSB(sb_index) != GPIO_PIN_RESET)
    {
        PID_Output(speed);
    }

    if (delay_after_detect_ms > 0)
    {
        HAL_Delay(delay_after_detect_ms);
    }
}


static void Route_RunOneSegment(RouteTrackMode_t mode, uint16_t speed, uint16_t duration_ms)
{
    switch (mode)
    {
    case ROUTE_TRACK_SINGLE:
        zhixian(speed, duration_ms);
        break;
    case ROUTE_TRACK_DUAL:
        dual_zhixian(speed, duration_ms);
        break;
    case ROUTE_TRACK_CIRCLE_DUAL:
        circle_dual_go(speed, duration_ms);
        break;
    default:
        break;
    }
}

static void Route_RunOneTask(const RouteTask_t *task)
{
    if (task == 0)
    {
        return;
    }

    switch (task->type)
    {
    case ROUTE_TASK_TYPE_MOVE:
        Route_RunOneSegment(task->data.move.mode,
                            task->data.move.speed,
                            task->data.move.duration_ms);
        break;
    case ROUTE_TASK_TYPE_STOP:
        stop();
        break;
    case ROUTE_TASK_TYPE_DELAY:
        if (task->data.delay_ms > 0)
        {
            HAL_Delay(task->data.delay_ms);
        }
        break;
    case ROUTE_TASK_TYPE_CALLBACK:
        if (task->data.hook.callback != 0)
        {
            task->data.hook.callback(task->data.hook.user_data);
        }
        break;
    default:
        break;
    }
}

void Route_RunActions(const RouteAction_t *actions,
                      uint16_t action_count,
                      uint8_t stop_between_actions,
                      uint16_t action_gap_ms)
{
    if (actions == 0 || action_count == 0)
    {
        return;
    }

    for (uint16_t i = 0; i < action_count; i++)
    {
        Route_RunOneSegment(actions[i].mode, actions[i].speed, actions[i].duration_ms);

        if (stop_between_actions)
        {
            stop();
        }

        if (action_gap_ms > 0)
        {
            HAL_Delay(action_gap_ms);
        }
    }
}

void Route_RunTasks(const RouteTask_t *tasks,
                   uint16_t task_count,
                   uint8_t stop_between_tasks,
                   uint16_t task_gap_ms)
{
    if (tasks == 0 || task_count == 0)
    {
        return;
    }

    for (uint16_t i = 0; i < task_count; i++)
    {
        Route_RunOneTask(&tasks[i]);

        if (stop_between_tasks)
        {
            stop();
        }

        if (task_gap_ms > 0)
        {
            HAL_Delay(task_gap_ms);
        }
    }
}
// ... existing code ...
