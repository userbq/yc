#include "../Inc/tlyuse.h"  // 声明本文件对外接口和配置宏
#include "tly.h"             // 陀螺仪数据结构与读取函数
#include "motor.h"           // 电机控制函数（Single_Motor/stop）
#include "math.h"            // 数学函数（fabsf）
#include "main.h"            // HAL、IRQ、GPIO 等主头文件
// #include "flash.h"        // 预留：历史上用于参数存储，当前未启用

float z_aim, z_begin, jd_begin, jd_last, tly_flag = 0;  // 全局目标角/记录角/状态标志
extern int shangqiao;                                    // 外部上桥状态标志（由其他模块维护）

float jd_load;                           // 实际要执行的转角（含预补偿后的结果）
float jd_more_cd = 15, jd_more_pt = 30; // 常规转弯/原地转弯的经验补偿角

#define tly_cd 20      // 草地转弯容差（度）
#define tly_pt 20      // 平台转弯容差（度）
#define pt_time 150    // 历史参数：平台动作附加延时（当前注释路径中未使用）

#define TURN_STABLE_COUNT 3      // 连续满足误差阈值次数，避免抖动触发提前结束
#define TURN_ERR_TOLERANCE 2.0f  // tlyuse_turn 默认转向误差阈值（度）
#define TURN_KP 4.0f             // 转向误差到PWM的比例增益
#define TURN_ARC_MIN_PWM 80      // 弧线转最小PWM，避免低速转不动
#define TURN_PT_MIN_PWM 120      // 原地转最小PWM，克服静摩擦
#define TURN_DIR_HOLD_ERR 6.0f   // 近目标时保持方向的误差带（度）
#define SPT_TIMEOUT_MS 2500U     // 上平台每阶段超时时间（ms）

// 将任意角度归一化到 [-180, 180]，用于跨越 ±180 时的连续比较。
static float tly_wrap_angle(float angle)
{
	while (angle > 180.0f) { angle -= 360.0f; }  // 超上界则回绕
	while (angle < -180.0f) { angle += 360.0f; } // 超下界则回绕
	return angle;                                 // 返回归一化角度
}

// 计算目标角与当前角的最短差值（带回绕处理）。
static float tly_angle_diff(float target, float current)
{
	return tly_wrap_angle(target - current); // 先相减再归一化
}

// 根据目标转角估算超时时间，转角越大给的时间越长，并做上下限保护。
static uint16_t tly_timeout_from_angle(float angle_abs)
{
	uint16_t timeout = (uint16_t)(450.0f + angle_abs * 14.0f); // 线性估算
	if (timeout < 450U) { timeout = 450U; }                    // 下限保护
	if (timeout > 3000U) { timeout = 3000U; }                  // 上限保护
	return timeout;                                             // 返回超时值
}

// 将 float 速度安全转换为 int16，避免异常值溢出。
static int16_t tly_speed_to_i16(float speed)
{
	if (speed > 32767.0f) { return 32767; }   // 正向饱和
	if (speed < -32768.0f) { return -32768; } // 反向饱和
	return (int16_t)speed;                    // 正常范围直接转换
}

// 按误差与模式输出电机转向控制：fs_mode=0 弧线转，fs_mode=1 原地转。
static void tly_apply_turn_output(float err, uint8_t fs_mode, uint16_t speed_max)
{
	float abs_err = fabsf(err); // 误差绝对值用于计算转向强度
	uint16_t min_pwm = (fs_mode == 1U) ? TURN_PT_MIN_PWM : TURN_ARC_MIN_PWM; // 选择最小起转PWM
	float pwm_f = (float)min_pwm + TURN_KP * abs_err; // 比例放大后得到目标PWM
	uint16_t pwm;        // 最终无符号PWM
	int16_t out_pwm;     // 发送给电机的主侧PWM
	int16_t out_inner;   // 弧线转时内侧电机保持的小PWM

	if (pwm_f < 0.0f)    // 理论保护：防止出现负值
	{
		pwm_f = 0.0f;      // 负值钳到0
	}
	pwm = (uint16_t)pwm_f; // 转成整型PWM

	if (speed_max == 0U) // 若调用方未传上限则给默认上限
	{
		speed_max = 240U;   // 默认限幅
	}
	if (pwm > speed_max) // 做最大值限幅
	{
		pwm = speed_max;    // 限到速度上限
	}
	out_pwm = (int16_t)pwm;              // 主侧输出值
	out_inner = (fs_mode == 1U) ? 0 : 20; // 原地转内侧为0，弧线转内侧保留20

	if (err > 0.0f) // 目标在左侧（按当前坐标系约定）
	{
		if (fs_mode == 1U) // 原地左转
		{
			Single_Motor(MOTOR_LEFT, (int16_t)-out_pwm); // 左轮后退
			Single_Motor(MOTOR_RIGHT, out_pwm);          // 右轮前进
		}
		else // 弧线左转
		{
			Single_Motor(MOTOR_LEFT, out_inner); // 左轮低速
			Single_Motor(MOTOR_RIGHT, out_pwm);  // 右轮高速
		}
	}
	else // 目标在右侧
	{
		if (fs_mode == 1U) // 原地右转
		{
			Single_Motor(MOTOR_LEFT, out_pwm);          // 左轮前进
			Single_Motor(MOTOR_RIGHT, (int16_t)-out_pwm); // 右轮后退
		}
		else // 弧线右转
		{
			Single_Motor(MOTOR_LEFT, out_pwm);   // 左轮高速
			Single_Motor(MOTOR_RIGHT, out_inner); // 右轮低速
		}
	}
}

// 闭环转到目标角：满足稳定次数或超时即退出。
static void tly_turn_to_target(float target_z,
							   uint8_t fs_mode,
							   uint16_t speed_max,
							   float err_tolerance,
							   uint16_t timeout_ms)
{
	uint32_t begin_ms = HAL_GetTick(); // 记录起始时刻
	uint8_t stable_count = 0U;         // 连续稳定计数器
	int8_t last_dir = 0;               // 近目标时方向保持器（1/-1）

	while (1) // 持续迭代直到满足退出条件
	{
		float err;                             // 当前角度误差
		tly_angle_read();                      // 刷新陀螺仪角度
		err = tly_angle_diff(target_z, tly.z_angle); // 计算最短角误差

		if (fabsf(err) <= err_tolerance) // 误差进入容差带
		{
			stable_count++;                 // 稳定计数+1
			if (stable_count >= TURN_STABLE_COUNT) // 连续满足足够次数
			{
				break;                       // 判定到位，退出转向
			}
		}
		else // 误差离开容差带
		{
			stable_count = 0U;             // 重新计数
		}

		if ((HAL_GetTick() - begin_ms) >= timeout_ms) // 超时保护
		{
			break; // 防止IMU异常或卡住导致死循环
		}

		// 近目标区域保持上一次方向，减少噪声导致的左右来回抖动。
		if (fabsf(err) < TURN_DIR_HOLD_ERR)
		{
			int8_t cur_dir = (err >= 0.0f) ? 1 : -1; // 当前方向符号
			if ((last_dir != 0) && (cur_dir != last_dir)) // 方向刚好反转
			{
				err = (last_dir > 0) ? fabsf(err) : -fabsf(err); // 强制保持旧方向
			}
			else
			{
				last_dir = cur_dir; // 记录当前方向
			}
		}
		else // 误差较大时正常更新方向
		{
			last_dir = (err >= 0.0f) ? 1 : -1; // 同步方向状态
		}

		tly_apply_turn_output(err, fs_mode, speed_max); // 根据误差输出电机
	}

	stop();         // 退出前统一刹车
	HAL_Delay(10); // 给机械系统一个短暂稳定时间
}

// 相对转角入口：开启IMU中断，计算目标角，调用统一闭环函数。
static void tly_turn_relative(float delta_angle,
						  uint8_t fs_mode,
						  uint16_t speed_max,
						  float err_tolerance)
{
	float start_z;      // 起始角
	float target_z;     // 目标角
	uint16_t timeout_ms; // 当前动作超时

	HAL_NVIC_EnableIRQ(USART2_IRQn); // 打开IMU串口中断，确保角度持续更新
	HAL_Delay(10);                   // 等待数据流稳定
	tly_angle_read();                // 先读一次最新角度

	start_z = tly.z_angle;                                   // 记录起点
	target_z = tly_wrap_angle(start_z + delta_angle);        // 计算目标角并回绕
	timeout_ms = tly_timeout_from_angle(fabsf(delta_angle)); // 按转角估算超时

	tly_turn_to_target(target_z, fs_mode, speed_max, err_tolerance, timeout_ms); // 执行闭环转向
	HAL_NVIC_DisableIRQ(USART2_IRQn); // 结束后关闭IMU串口中断
}

// 当前目标角误差查询函数，保留给外部流程复用。
float tly_err(void)
{
	float k;                             // 输出误差
	tly_angle_read();                    // 读取最新角度
	k = fabsf(tly_angle_diff(z_aim, tly.z_angle)); // 计算目标角绝对误差
	return k;                            // 返回误差
}

// 通用转弯函数：支持补偿角、不同转向模式与速度上限。
void tlyuse_turn(float jd, uint8_t fs_mode, uint8_t wz_mode, uint16_t speed_turn)
{
	float jd_more = 0.0f; // 当前动作使用的补偿角
	float start_z;        // 起始角
	float target_z;       // 目标角

	if(speed_turn == 250U) // 仅在该速度档启用经验补偿
	{
		if(wz_mode == 0U)      // 常规弯道模式
		{
			jd_more = jd_more_cd; // 使用常规补偿
		}
		else if(wz_mode == 1U) // 平台/特殊弯道模式
		{
			jd_more = jd_more_pt; // 使用更大补偿
		}
	}

	if(jd > jd_more) // 正向角度且大于补偿
	{
		jd_load = jd - jd_more; // 扣减补偿后执行
	}
	else if(jd < -jd_more) // 反向角度且幅值大于补偿
	{
		jd_load = jd + jd_more; // 反向加回补偿
	}
	else // 角度较小，不做补偿
	{
		jd_load = jd; // 直接执行原角度
	}

	HAL_NVIC_EnableIRQ(USART2_IRQn); // 开中断以更新IMU
	HAL_Delay(10);                   // 等数据稳定
	tly_angle_read();                // 读取起始角
	start_z = tly.z_angle;           // 保存起始角
	target_z = tly_wrap_angle(start_z + jd_load); // 计算目标角

	tly_turn_to_target(target_z,
					   fs_mode,
					   speed_turn,
					   TURN_ERR_TOLERANCE,
					   tly_timeout_from_angle(fabsf(jd_load))); // 进入闭环执行

	HAL_NVIC_DisableIRQ(USART2_IRQn); // 关闭IMU中断
	HAL_Delay(40);                    // 动作结束后等待车体稳定
}

// 左转（弧线模式）封装接口。
void Tly_L(float angle)
{
	tly_turn_relative(fabsf(angle), 0U, 350U, (float)tly_cd); // 正角度表示左转
}

// 右转（弧线模式）封装接口。
void Tly_R(float angle)
{
	tly_turn_relative(-fabsf(angle), 0U, 350U, (float)tly_cd); // 负角度表示右转
}

// 左转（原地模式）封装接口。
void Tly_L_pt(float angle)
{
	tly_turn_relative(fabsf(angle), 1U, 250U, (float)tly_pt); // fs_mode=1 为原地转
}

// 右转（原地模式）封装接口。
void Tly_R_pt(float angle)
{
	tly_turn_relative(-fabsf(angle), 1U, 250U, (float)tly_pt); // fs_mode=1 为原地转
}

// 上平台动作：通过X轴倾角上升后回落的特征来判定时机。
void tlyuse_spt(float speed)
{
	float x_angle_dir;   // 经方向系数修正后的倾角
	uint32_t begin_ms;   // 阶段起始时间，用于超时保护
	int16_t left_cmd;    // 左电机命令值
	int16_t right_cmd;   // 右电机命令值
	HAL_NVIC_EnableIRQ(USART2_IRQn); // 打开IMU串口中断
	HAL_Delay(10);                   // 等待角度数据稳定
	tly_angle_read();                // 读取初始倾角
	jd_begin = tly.x_angle * TLYUSE_SPT_TILT_DIR; // 记录起始倾角（含安装方向修正）
	jd_last = jd_begin + 10;                        // 设定阈值：先上升约10度
	left_cmd = tly_speed_to_i16(speed + 3.0f);      // 左轮给一点补偿，抵消机械偏差
	right_cmd = tly_speed_to_i16(speed);            // 右轮基础速度
	Single_Motor(MOTOR_LEFT, left_cmd);             // 下发左轮速度
	Single_Motor(MOTOR_RIGHT, right_cmd);           // 下发右轮速度
	begin_ms = HAL_GetTick();                       // 第一阶段计时起点
	while(1) // 第一阶段：等待倾角上升到阈值
	{
		// PID_Output(speed); // 如需直线闭环可在此启用
		if ((HAL_GetTick() - begin_ms) > SPT_TIMEOUT_MS) // 超时即退出阶段
		{
			break; // 防止一直等不到阈值
		}
		tly_angle_read();                            // 刷新IMU数据
		x_angle_dir = tly.x_angle * TLYUSE_SPT_TILT_DIR; // 计算修正后倾角
		if(x_angle_dir > jd_last)                   // 达到上升阈值
		{
			//HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8,GPIO_PIN_RESET); // 预留调试点
			break; // 进入第二阶段
		}
	}
	begin_ms = HAL_GetTick(); // 第二阶段重新计时
	while(1) // 第二阶段：等待倾角回落，判定通过平台顶点
	{
		// dual_PID_Output(speed); // 如需双线闭环可在此启用
		if ((HAL_GetTick() - begin_ms) > SPT_TIMEOUT_MS) // 超时保护
		{
			break; // 避免异常卡死
		}
		tly_angle_read();                            // 刷新IMU数据
		x_angle_dir = tly.x_angle * TLYUSE_SPT_TILT_DIR; // 计算修正后倾角
		if(x_angle_dir < jd_last)                   // 倾角开始回落到阈值下
		{
			//HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8,GPIO_PIN_RESET); // 预留调试点
			HAL_Delay(20); // 回落后短暂延时，过滤瞬时噪声
			break; // 上平台判定结束
		}
	}
	HAL_NVIC_DisableIRQ(USART2_IRQn); // 关闭IMU串口中断
	// if(shangqiao==0) // 历史流程：上桥后停车
	// {
	// 	HAL_Delay(pt_time);
	// 	stop();
	// 	HAL_Delay(10);
	// }
	// else HAL_Delay(10);
}


