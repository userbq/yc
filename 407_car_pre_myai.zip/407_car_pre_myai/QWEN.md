# 407_car - STM32F407 智能车项目

## 项目概述

这是一个基于 **STM32F407VET6** 微控制器的智能车控制系统项目。项目使用 STM32CubeMX 生成基础配置，并通过 CLion IDE 进行开发。

### 主要功能

- **电机控制**：支持左右电机独立控制，包括正转、反转、停止
- **编码器反馈**：使用 TIM2 和 TIM4 进行编码器数据采集
- **PID 控制**：实现电机速度闭环控制
- **双线循迹**：支持双路7路灰度传感器巡线功能（UART4/UART5）
- **OLED 显示**：实时显示系统状态和传感器数据
- **多串口通信**：支持6个串口（USART1/2/3、UART4/5、USART6）用于传感器通信和调试
- **PWM 输出**：TIM3 和 TIM12 提供 PWM 信号
- **Flash 存储**：支持参数掉电保存

### 硬件架构

**主控芯片**：STM32F407VET6 (LQFP100)

**时钟配置**：
- 外部高速晶振 (HSE)：8MHz
- 系统时钟 (SYSCLK)：168MHz
- AHB：168MHz，APB1：42MHz，APB2：84MHz

**关键外设**：
| 外设 | 引脚 | 功能 |
|------|------|------|
| OLED_SDA | PB5 | OLED 数据线 |
| OLED_SCK | PB6 | OLED 时钟线 |
| OLED_DC | PB3 | OLED 数据/命令 |
| OLED_RES | PB4 | OLED 复位 |
| OLED_CS | PD7 | OLED 片选 |
| LED1 | PA5 | 状态指示灯 |
| LED2 | PA6 | 状态指示灯 |
| USART1 | PA9/PA10 | 调试串口 |
| USART2 | PD5/PD6 | 传感器串口 |
| USART3 | PB10/PB11 | 传感器串口 |
| UART4 | PC10/PC11 | 左侧灰度传感器 |
| UART5 | PC12/PD2 | 右侧灰度传感器 |
| USART6 | PC6/PC7 | 扩展串口 |
| TIM2 | PA0/PA1 | 编码器接口 |
| TIM3 | PC8/PC9 | PWM 输出 |
| TIM4 | PD12/PD13 | 编码器接口 |
| TIM12 | PB14/PB15 | PWM 输出 |

## 项目结构

```
407_car/
├── Core/                  # STM32CubeMX 生成的核心代码
│   ├── Inc/               # 头文件 (main.h, gpio.h, tim.h, usart.h)
│   └── Src/               # 源文件 (main.c, gpio.c, tim.c, usart.c)
├── Drivers/               # STM32 标准库
│   ├── CMSIS/             # ARM CMSIS 库
│   └── STM32F4xx_HAL_Driver/  # STM32 HAL 驱动库
├── HARDWARE/              # 硬件驱动代码
│   ├── Inc/               # 硬件头文件
│   └── Src/               # 硬件源文件
│       ├── motor.c        # 电机控制
│       ├── encoder.c      # 编码器读取
│       ├── huidu.c        # 灰度传感器处理 & PID
│       ├── OLED.c         # OLED 显示屏驱动
│       ├── show.c         # OLED 显示逻辑
│       ├── tly.c          # 舵机控制
│       ├── tlyuse.c       # 舵机使用封装
│       ├── wit_c_sdk.c    # WitMotion 传感器 SDK
│       └── dual_line_test.c  # 双线循迹测试
├── soft_user/             # 用户软件层
│   ├── Inc/               # 头文件
│   └── src/               # 源文件
│       ├── pid.c          # PID 控制器实现
│       ├── speed_con.c    # 速度控制器
│       ├── route.c        # 路线/路径规划
│       ├── delay.c        # 延时函数
│       └── myflash.c      # Flash 读写操作
├── cmake/                 # CMake 工具链配置
│   └── gcc-arm-none-eabi.cmake
├── CMakeLists.txt         # 主 CMake 构建配置
├── CMakePresets.json      # CMake 预设配置 (Debug/Release)
├── 407_car.ioc            # STM32CubeMX 项目文件
├── STM32F407XX_FLASH.ld   # 链接脚本
└── startup_stm32f407xx.s  # 启动文件
```

## 构建和运行

### 环境要求

- **工具链**：ARM GCC (`arm-none-eabi-gcc`)
- **构建系统**：Ninja
- **CMake**：≥ 3.22
- **IDE**：CLion (推荐)

### 构建命令

```bash
# 配置项目 (Debug 模式)
cmake --preset=Debug

# 编译项目
cmake --build --preset=Debug

# 或者 Release 模式
cmake --preset=Release
cmake --build --preset=Release
```

### 烧录

编译成功后，生成的 `.elf` 文件位于 `build/Debug/` 或 `build/Release/` 目录。使用 ST-Link 或其他编程工具烧录到目标板。

## 开发约定

### 代码风格

- **语言标准**：C11 (带 GNU 扩展)
- **命名约定**：
  - 函数名：大驼峰 (如 `Motor_Init()`, `PID_Output()`)
  - 宏定义：全大写下划线分隔 (如 `MOTOR_H`)
  - 全局变量：小写下划线分隔 (如 `left_line_err`)
- **文件组织**：头文件在 `Inc/`，源文件在 `Src/`

### 模块划分

| 模块 | 职责 |
|------|------|
| `HARDWARE/` | 底层硬件驱动，直接操作外设寄存器或 HAL 库 |
| `soft_user/` | 应用层逻辑，如 PID 算法、路径规划、延时处理 |
| `Core/` | STM32CubeMX 生成的系统初始化和外设配置代码 |

### 调试建议

- 使用 USART1 (PA9/PA10) 作为调试串口，支持 `printf` 重定向
- OLED 显示屏可用于实时显示传感器数据和系统状态
- 可通过 `show_huidu()` 和 `show_tly()` 函数查看传感器状态

## 关键算法

### 双线循迹 PID

- **误差计算**：根据7路灰度传感器返回值映射误差
- **PID 参数**：KP=25, KI=0, KD=8 (可在 `huidu.c` 中调整)
- **权重融合**：左右传感器误差按权重融合，适应30cm线距

### 电机控制

- **编码器反馈**：TIM2 (左) 和 TIM4 (右) 采集编码器脉冲
- **速度闭环**：PID 控制器调节 PWM 占空比
- **双电机同步**：支持左右电机速度协调控制

## 注意事项

1. **工具链路径**：确保 `arm-none-eabi-gcc` 已添加到系统环境变量
2. **传感器校准**：首次使用灰度传感器时，需根据实际返回值更新误差映射表
3. **PID 参数整定**：建议从小 KP/KD 开始，逐步调整避免车身抖动
4. **Flash 操作**：写入 Flash 前需确保已正确解锁并擦除扇区
